<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/playlists.php';
require_once __DIR__ . '/../includes/helpers.php';

header('Content-Type: application/json');
Auth::requireLogin();

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'list':
        $playlists = PlaylistManager::getAll(Auth::getUser()['id']);
        jsonResponse(['success' => true, 'playlists' => $playlists]);
        break;
        
    case 'get':
        $id = (int)($_GET['id'] ?? 0);
        if (!$id) jsonResponse(['success' => false, 'error' => 'Invalid playlist ID'], 400);
        
        $playlist = PlaylistManager::getById($id);
        if (!$playlist) jsonResponse(['success' => false, 'error' => 'Playlist not found'], 404);
        
        $tracks = PlaylistManager::getTracks($id);
        jsonResponse(['success' => true, 'playlist' => $playlist, 'tracks' => $tracks]);
        break;
        
    case 'create':
        $name = trim($_POST['name'] ?? '');
        if (empty($name)) jsonResponse(['success' => false, 'error' => 'Playlist name required'], 400);
        
        $result = PlaylistManager::create($name, $_POST['description'] ?? '', Auth::getUser()['id']);
        jsonResponse($result, $result['success'] ? 201 : 400);
        break;
        
    case 'update':
        $id = (int)($_POST['id'] ?? 0);
        if (!$id) jsonResponse(['success' => false, 'error' => 'Invalid playlist ID'], 400);
        
        $result = PlaylistManager::update($id, $_POST['name'] ?? '', $_POST['description'] ?? '');
        jsonResponse($result);
        break;
        
    case 'delete':
        Auth::requireAdmin();
        $id = (int)($_POST['id'] ?? 0);
        if (!$id) jsonResponse(['success' => false, 'error' => 'Invalid playlist ID'], 400);
        
        $result = PlaylistManager::delete($id);
        jsonResponse($result);
        break;
        
    case 'toggle_active':
        Auth::requireAdmin();
        $id = (int)($_POST['id'] ?? 0);
        $result = PlaylistManager::toggleActive($id);
        jsonResponse($result);
        break;
        
    case 'add_track':
        $playlistId = (int)($_POST['playlist_id'] ?? 0);
        $trackId = (int)($_POST['track_id'] ?? 0);
        
        if (!$playlistId || !$trackId) jsonResponse(['success' => false, 'error' => 'Missing parameters'], 400);
        
        $result = PlaylistManager::addTrack($playlistId, $trackId);
        jsonResponse($result, $result['success'] ? 200 : 400);
        break;
        
    case 'remove_track':
        $playlistId = (int)($_POST['playlist_id'] ?? 0);
        $trackId = (int)($_POST['track_id'] ?? 0);
        
        if (!$playlistId || !$trackId) jsonResponse(['success' => false, 'error' => 'Missing parameters'], 400);
        
        $result = PlaylistManager::removeTrack($playlistId, $trackId);
        jsonResponse($result);
        break;
        
    case 'reorder':
        $playlistId = (int)($_POST['playlist_id'] ?? 0);
        $trackId = (int)($_POST['track_id'] ?? 0);
        $position = (int)($_POST['position'] ?? 1);
        
        if (!$playlistId || !$trackId) jsonResponse(['success' => false, 'error' => 'Missing parameters'], 400);
        
        $result = PlaylistManager::reorderTrack($playlistId, $trackId, max(1, $position));
        jsonResponse($result);
        break;
        
    default:
        jsonResponse(['success' => false, 'error' => 'Unknown action'], 400);
}