<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'login':
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';
        
        if (empty($username) || empty($password)) {
            jsonResponse(['success' => false, 'error' => 'Username and password required'], 400);
        }
        
        if (Auth::login($username, $password)) {
            $user = Auth::getUser();
            jsonResponse([
                'success' => true,
                'user' => $user,
                'force_password_change' => $user['force_password_change']
            ]);
        } else {
            jsonResponse(['success' => false, 'error' => 'Invalid credentials'], 401);
        }
        break;
        
    case 'logout':
        Auth::logout();
        jsonResponse(['success' => true]);
        break;
        
    case 'change_password':
        Auth::requireLogin();
        $user = Auth::getUser();
        $current = $_POST['current_password'] ?? '';
        $new = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';
        
        if ($new !== $confirm) {
            jsonResponse(['success' => false, 'error' => 'New passwords do not match'], 400);
        }
        
        $result = Auth::changePassword($user['id'], $current, $new);
        jsonResponse($result, $result['success'] ? 200 : 400);
        break;
        
    case 'status':
        Auth::requireLogin();
        $user = Auth::getUser();
        $autodjStatus = AutoDJ::getStatus();
        $nowPlaying = getNowPlaying();
        $icecastStatus = getIcecastStatus();
        
        jsonResponse([
            'success' => true,
            'user' => $user,
            'autodj' => $autodjStatus,
            'now_playing' => $nowPlaying,
            'icecast' => $icecastStatus,
            'live' => LiveTakeover::isLiveActive()
        ]);
        break;
        
    default:
        jsonResponse(['success' => false, 'error' => 'Unknown action'], 400);
}