<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/schedule.php';
require_once __DIR__ . '/../includes/helpers.php';

header('Content-Type: application/json');
Auth::requireAdmin();

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'list':
        $schedules = ScheduleManager::getAll();
        jsonResponse(['success' => true, 'schedules' => $schedules]);
        break;
        
    case 'create':
        $playlistId = (int)($_POST['playlist_id'] ?? 0);
        $day = $_POST['day_of_week'] ?? '';
        $start = $_POST['start_time'] ?? '';
        $end = $_POST['end_time'] ?? '';
        
        if (!$playlistId || !$day || !$start || !$end) {
            jsonResponse(['success' => false, 'error' => 'All fields required'], 400);
        }
        
        $result = ScheduleManager::create($playlistId, $day, $start, $end);
        jsonResponse($result, $result['success'] ? 201 : 400);
        break;
        
    case 'delete':
        $id = (int)($_POST['id'] ?? 0);
        $result = ScheduleManager::delete($id);
        jsonResponse($result);
        break;
        
    case 'toggle':
        $id = (int)($_POST['id'] ?? 0);
        $result = ScheduleManager::toggleActive($id);
        jsonResponse($result);
        break;
        
    default:
        jsonResponse(['success' => false, 'error' => 'Unknown action'], 400);
}