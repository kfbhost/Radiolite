<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/live.php';
require_once __DIR__ . '/../includes/helpers.php';

header('Content-Type: application/json');
Auth::requireDJ();

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'status':
        jsonResponse(LiveTakeover::isLiveActive());
        break;
        
    case 'request':
        $result = LiveTakeover::requestTakeover(Auth::getUser()['id']);
        jsonResponse($result, $result['success'] ? 200 : 400);
        break;
        
    case 'end':
        $token = $_POST['token'] ?? '';
        if (empty($token)) {
            jsonResponse(['success' => false, 'error' => 'Token required'], 400);
        }
        $result = LiveTakeover::endTakeover($token);
        jsonResponse($result);
        break;
        
    case 'config':
        jsonResponse([
            'success' => true,
            'host' => LiveTakeover::getIcecastHost(),
            'port' => LiveTakeover::getIcecastPort(),
            'mount' => LiveTakeover::getIcecastMount(),
            'password' => LiveTakeover::getIcecastSourcePassword()
        ]);
        break;
        
    default:
        jsonResponse(['success' => false, 'error' => 'Unknown action'], 400);
}