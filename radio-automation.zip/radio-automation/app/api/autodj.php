<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/autodj.php';
require_once __DIR__ . '/../includes/helpers.php';

header('Content-Type: application/json');

// Allow status check without full auth for public status
$action = $_POST['action'] ?? $_GET['action'] ?? '';

if ($action !== 'status' && $action !== 'config') {
    Auth::requireAdmin();
}

switch ($action) {
    case 'status':
        jsonResponse(AutoDJ::getStatus());
        break;
        
    case 'start':
        $result = AutoDJ::start();
        jsonResponse($result, $result['success'] ? 200 : 400);
        break;
        
    case 'stop':
        $result = AutoDJ::stop();
        jsonResponse($result);
        break;
        
    case 'restart':
        $result = AutoDJ::restart();
        jsonResponse($result, $result['success'] ? 200 : 400);
        break;
        
    case 'config':
        $settings = Config::getStreamSettings();
        $icecast = Config::getIcecastConfig();
        jsonResponse([
            'success' => true,
            'settings' => $settings,
            'icecast' => $icecast
        ]);
        break;
        
    case 'save_settings':
        $data = [
            'stream_name' => $_POST['stream_name'] ?? '',
            'stream_genre' => $_POST['stream_genre'] ?? '',
            'stream_url' => $_POST['stream_url'] ?? '',
            'stream_description' => $_POST['stream_description'] ?? '',
            'icecast_host' => $_POST['icecast_host'] ?? '',
            'icecast_port' => (int)($_POST['icecast_port'] ?? 8000),
            'icecast_mount' => $_POST['icecast_mount'] ?? '/stream',
            'icecast_password' => $_POST['icecast_password'] ?? '',
            'bitrate' => (int)($_POST['bitrate'] ?? 128),
            'samplerate' => (int)($_POST['samplerate'] ?? 44100),
            'channels' => (int)($_POST['channels'] ?? 2),
            'format' => $_POST['format'] ?? 'mp3'
        ];
        
        $result = Config::saveStreamSettings($data);
        AutoDJ::generateLiquidsoapConfig($data);
        jsonResponse($result);
        break;
        
    default:
        jsonResponse(['success' => false, 'error' => 'Unknown action'], 400);
}