<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/tracks.php';
require_once __DIR__ . '/../includes/helpers.php';

header('Content-Type: application/json');
Auth::requireLogin();

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'list':
        $search = $_GET['search'] ?? '';
        $page = max(1, (int)($_GET['page'] ?? 1));
        $limit = 50;
        $offset = ($page - 1) * $limit;
        
        $tracks = TrackManager::getAll($search, $offset, $limit);
        $count = TrackManager::getCount($search);
        
        jsonResponse([
            'success' => true,
            'tracks' => $tracks,
            'total' => $count,
            'page' => $page,
            'pages' => ceil($count / $limit)
        ]);
        break;
        
    case 'upload':
        if (!isset($_FILES['file'])) {
            jsonResponse(['success' => false, 'error' => 'No file uploaded'], 400);
        }
        
        $result = TrackManager::upload($_FILES['file']);
        jsonResponse($result, $result['success'] ? 200 : 400);
        break;
        
    case 'bulk_upload':
        if (!isset($_FILES['files'])) {
            jsonResponse(['success' => false, 'error' => 'No files uploaded'], 400);
        }
        
        $result = TrackManager::bulkUpload($_FILES['files']);
        jsonResponse($result);
        break;
        
    case 'delete':
        $id = (int)($_POST['id'] ?? 0);
        if (!$id) jsonResponse(['success' => false, 'error' => 'Invalid track ID'], 400);
        
        $result = TrackManager::delete($id);
        jsonResponse($result, $result['success'] ? 200 : 400);
        break;
        
    case 'metadata':
        $id = (int)($_POST['id'] ?? 0);
        if (!$id) jsonResponse(['success' => false, 'error' => 'Invalid track ID'], 400);
        
        $result = TrackManager::updateMetadata($id, $_POST);
        jsonResponse($result);
        break;
        
    case 'scan':
        Auth::requireAdmin();
        $result = TrackManager::scanDirectory();
        jsonResponse($result);
        break;
        
    default:
        jsonResponse(['success' => false, 'error' => 'Unknown action'], 400);
}