<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/users.php';
require_once __DIR__ . '/../includes/helpers.php';

header('Content-Type: application/json');
Auth::requireAdmin();

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'list':
        $users = UserManager::getAll();
        jsonResponse(['success' => true, 'users' => $users]);
        break;
        
    case 'create':
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $email = trim($_POST['email'] ?? '');
        $role = $_POST['role'] ?? 'dj';
        
        if (empty($username) || empty($password)) {
            jsonResponse(['success' => false, 'error' => 'Username and password required'], 400);
        }
        
        if (strlen($password) < 8) {
            jsonResponse(['success' => false, 'error' => 'Password must be at least 8 characters'], 400);
        }
        
        $result = UserManager::create($username, $password, $email, $role);
        jsonResponse($result, $result['success'] ? 201 : 400);
        break;
        
    case 'update':
        $id = (int)($_POST['id'] ?? 0);
        if (!$id) jsonResponse(['success' => false, 'error' => 'Invalid user ID'], 400);
        
        $data = [];
        if (isset($_POST['email'])) $data['email'] = $_POST['email'];
        if (isset($_POST['role'])) $data['role'] = $_POST['role'];
        if (isset($_POST['is_active'])) $data['is_active'] = (int)$_POST['is_active'];
        
        $result = UserManager::update($id, $data);
        jsonResponse($result);
        break;
        
    case 'delete':
        $id = (int)($_POST['id'] ?? 0);
        if (!$id) jsonResponse(['success' => false, 'error' => 'Invalid user ID'], 400);
        
        // Prevent self-deletion
        if ($id === Auth::getUser()['id']) {
            jsonResponse(['success' => false, 'error' => 'Cannot delete yourself'], 400);
        }
        
        $result = UserManager::delete($id);
        jsonResponse($result, $result['success'] ? 200 : 400);
        break;
        
    case 'toggle_active':
        $id = (int)($_POST['id'] ?? 0);
        $result = UserManager::toggleActive($id);
        jsonResponse($result);
        break;
        
    case 'active_djs':
        $djs = UserManager::getActiveDJs();
        jsonResponse(['success' => true, 'djs' => $djs]);
        break;
        
    default:
        jsonResponse(['success' => false, 'error' => 'Unknown action'], 400);
}