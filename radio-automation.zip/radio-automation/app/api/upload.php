<?php
/**
 * RadioLite - File Upload Handler
 */

define('APP_DIR', '/opt/radiolite');
define('UPLOAD_DIR', APP_DIR . '/uploads');
define('MUSIC_DIR', APP_DIR . '/music');
define('MAX_FILE_SIZE', 50 * 1024 * 1024); // 50MB

require_once APP_DIR . '/app/config/db.php';
require_once APP_DIR . '/app/config/config.php';
require_once APP_DIR . '/app/includes/auth.php';
require_once APP_DIR . '/app/includes/tracks.php';
require_once APP_DIR . '/app/includes/helpers.php';

header('Content-Type: application/json');
Auth::requireLogin();

// Handle CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Methods: POST, OPTIONS");
    header("Access-Control-Allow-Headers: Content-Type");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

// Handle single file upload
if (isset($_FILES['file'])) {
    $result = TrackManager::upload($_FILES['file']);
    echo json_encode($result);
    exit;
}

// Handle bulk upload
if (isset($_FILES['files'])) {
    $result = TrackManager::bulkUpload($_FILES['files']);
    echo json_encode($result);
    exit;
}

// Handle base64 upload (for drag-drop from browser)
if (isset($_POST['base64'])) {
    $data = $_POST['base64'];
    $filename = $_POST['filename'] ?? 'track_' . time();
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    
    if (!in_array($extension, Config::ALLOWED_EXTENSIONS)) {
        echo json_encode(['success' => false, 'error' => 'File type not allowed']);
        exit;
    }
    
    $decoded = base64_decode(preg_replace('#^data:audio/\w+;base64,#i', '', $data));
    $newFilename = bin2hex(random_bytes(16)) . '.' . $extension;
    $filepath = MUSIC_DIR . '/' . $newFilename;
    
    if (file_put_contents($filepath, $decoded)) {
        chmod($filepath, 0644);
        $metadata = getAudioMetadata($filepath);
        
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("
            INSERT INTO tracks (filename, filepath, title, artist, album, genre, year, duration, bitrate, filesize, upload_user_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $filename,
            $filepath,
            $metadata['title'] ?: pathinfo($filename, PATHINFO_FILENAME),
            $metadata['artist'] ?: 'Unknown Artist',
            $metadata['album'] ?: '',
            $metadata['genre'] ?: '',
            $metadata['year'] ?: null,
            $metadata['duration'],
            $metadata['bitrate'],
            strlen($decoded),
            $_SESSION['user_id'] ?? null
        ]);
        
        rebuildMainPlaylist();
        
        echo json_encode([
            'success' => true,
            'track_id' => $db->lastInsertId(),
            'metadata' => $metadata
        ]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to save file']);
    }
    exit;
}

echo json_encode(['success' => false, 'error' => 'No file provided']);