<?php
/**
 * RadioLite - Database Configuration
 */
class Database {
    private static $instance = null;
    private $db;
    
    private function __construct() {
        $dbPath = '/opt/radiolite/config/radiolite.db';
        $this->db = new PDO("sqlite:" . $dbPath);
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $this->db->exec("PRAGMA journal_mode=WAL");
        $this->db->exec("PRAGMA foreign_keys=ON");
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getConnection() {
        return $this->db;
    }
    
    public static function init() {
        $dbPath = '/opt/radiolite/config/radiolite.db';
        $db = new PDO("sqlite:" . $dbPath);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        $db->exec("CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            email TEXT,
            role TEXT DEFAULT 'dj',
            force_password_change INTEGER DEFAULT 0,
            is_active INTEGER DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_login DATETIME
        )");
        
        $db->exec("CREATE TABLE IF NOT EXISTS tracks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT NOT NULL,
            filepath TEXT NOT NULL,
            title TEXT,
            artist TEXT,
            album TEXT,
            genre TEXT,
            year INTEGER,
            duration REAL,
            bitrate INTEGER,
            filesize INTEGER,
            upload_date DATETIME DEFAULT CURRENT_TIMESTAMP,
            upload_user_id INTEGER,
            is_active INTEGER DEFAULT 1
        )");
        
        $db->exec("CREATE TABLE IF NOT EXISTS playlists (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            is_active INTEGER DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            created_by INTEGER,
            play_count INTEGER DEFAULT 0
        )");
        
        $db->exec("CREATE TABLE IF NOT EXISTS playlist_tracks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            playlist_id INTEGER NOT NULL,
            track_id INTEGER NOT NULL,
            position INTEGER,
            play_count INTEGER DEFAULT 0,
            last_played DATETIME,
            FOREIGN KEY (playlist_id) REFERENCES playlists(id) ON DELETE CASCADE,
            FOREIGN KEY (track_id) REFERENCES tracks(id) ON DELETE CASCADE
        )");
        
        $db->exec("CREATE TABLE IF NOT EXISTS stream_settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            stream_name TEXT DEFAULT 'RadioLite',
            stream_genre TEXT DEFAULT 'Various',
            stream_url TEXT DEFAULT 'http://localhost',
            stream_description TEXT DEFAULT 'RadioLite Internet Radio',
            icecast_host TEXT DEFAULT 'localhost',
            icecast_port INTEGER DEFAULT 8000,
            icecast_mount TEXT DEFAULT '/stream',
            icecast_password TEXT DEFAULT 'hackme',
            bitrate INTEGER DEFAULT 128,
            samplerate INTEGER DEFAULT 44100,
            channels INTEGER DEFAULT 2,
            format TEXT DEFAULT 'mp3',
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");
        
        $db->exec("CREATE TABLE IF NOT EXISTS schedule (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            playlist_id INTEGER NOT NULL,
            day_of_week TEXT,
            start_time TEXT NOT NULL,
            end_time TEXT NOT NULL,
            is_active INTEGER DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (playlist_id) REFERENCES playlists(id) ON DELETE CASCADE
        )");
        
        $db->exec("CREATE TABLE IF NOT EXISTS now_playing (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            track_id INTEGER,
            title TEXT,
            artist TEXT,
            started_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");
        
        $db->exec("CREATE TABLE IF NOT EXISTS dj_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            session_token TEXT UNIQUE NOT NULL,
            ip_address TEXT,
            connected_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            disconnected_at DATETIME,
            is_active INTEGER DEFAULT 1,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )");
        
        $db->exec("CREATE INDEX IF NOT EXISTS idx_tracks_artist ON tracks(artist)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_tracks_title ON tracks(title)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_playlist_tracks_playlist ON playlist_tracks(playlist_id)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_schedule_playlist ON schedule(playlist_id)");
        
        $db = null;
    }
}