<?php
/**
 * RadioLite - Application Configuration
 */
class Config {
    const APP_NAME = 'RadioLite';
    const APP_VERSION = '1.0.0';
    
    const INSTALL_DIR = '/opt/radiolite';
    const APP_DIR = '/opt/radiolite/app';
    const PUBLIC_DIR = '/opt/radiolite/public';
    const MUSIC_DIR = '/opt/radiolite/music';
    const UPLOAD_DIR = '/opt/radiolite/uploads';
    const CONFIG_DIR = '/opt/radiolite/config';
    const LOG_DIR = '/opt/radiolite/logs';
    const SCRIPTS_DIR = '/opt/radiolite/scripts';
    const PLAYLISTS_DIR = '/opt/radiolite/playlists';
    
    const DB_PATH = '/opt/radiolite/config/radiolite.db';
    
    const ICECAST_CONFIG = '/opt/radiolite/config/icecast.conf';
    const LIQUIDSOAP_SCRIPT = '/opt/radiolite/scripts/autodj.liq';
    const MAIN_PLAYLIST = '/opt/radiolite/playlists/main.m3u';
    
    const SESSION_NAME = 'radiolite_session';
    const SESSION_DURATION = 3600;
    
    const MAX_UPLOAD_SIZE = 50 * 1024 * 1024; // 50MB
    const ALLOWED_EXTENSIONS = ['mp3', 'ogg', 'flac', 'wav', 'm4a', 'aac'];
    
    const DEFAULT_STREAM_NAME = 'RadioLite';
    const DEFAULT_BITRATE = 128;
    const DEFAULT_SAMPLERATE = 44100;
    const DEFAULT_CHANNELS = 2;
    const DEFAULT_FORMAT = 'mp3';
    
    public static function getIcecastConfig() {
        $config = [];
        if (file_exists(self::ICECAST_CONFIG)) {
            $lines = file(self::ICECAST_CONFIG, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            foreach ($lines as $line) {
                if (strpos($line, '=') !== false) {
                    list($key, $value) = explode('=', $line, 2);
                    $config[trim($key)] = trim($value);
                }
            }
        }
        return $config;
    }
    
    public static function getStreamSettings() {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->query("SELECT * FROM stream_settings ORDER BY id DESC LIMIT 1");
        $settings = $stmt->fetch();
        if (!$settings) {
            $settings = [
                'stream_name' => self::DEFAULT_STREAM_NAME,
                'stream_genre' => 'Various',
                'stream_url' => 'http://localhost',
                'stream_description' => 'RadioLite Internet Radio',
                'icecast_host' => 'localhost',
                'icecast_port' => 8000,
                'icecast_mount' => '/stream',
                'icecast_password' => 'hackme',
                'bitrate' => self::DEFAULT_BITRATE,
                'samplerate' => self::DEFAULT_SAMPLERATE,
                'channels' => self::DEFAULT_CHANNELS,
                'format' => self::DEFAULT_FORMAT
            ];
        }
        return $settings;
    }
    
    public static function saveStreamSettings($data) {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("
            UPDATE stream_settings SET 
                stream_name = ?, stream_genre = ?, stream_url = ?, 
                stream_description = ?, icecast_host = ?, icecast_port = ?,
                icecast_mount = ?, icecast_password = ?, bitrate = ?,
                samplerate = ?, channels = ?, format = ?, updated_at = datetime('now')
            WHERE id = (SELECT id FROM stream_settings ORDER BY id DESC LIMIT 1)
        ");
        $stmt->execute([
            $data['stream_name'] ?? 'RadioLite',
            $data['stream_genre'] ?? 'Various',
            $data['stream_url'] ?? 'http://localhost',
            $data['stream_description'] ?? 'RadioLite Internet Radio',
            $data['icecast_host'] ?? 'localhost',
            $data['icecast_port'] ?? 8000,
            $data['icecast_mount'] ?? '/stream',
            $data['icecast_password'] ?? 'hackme',
            $data['bitrate'] ?? 128,
            $data['samplerate'] ?? 44100,
            $data['channels'] ?? 2,
            $data['format'] ?? 'mp3'
        ]);
        return ['success' => true];
    }
}