<?php
/**
 * RadioLite - Playlist Management
 */
class PlaylistManager {
    
    public static function getAll($userId = null) {
        $db = Database::getInstance()->getConnection();
        
        $where = '';
        $params = [];
        
        if ($userId !== null) {
            $where = "WHERE p.created_by = ? OR p.is_active = 1";
            $params = [$userId];
        }
        
        $stmt = $db->prepare("
            SELECT p.*, u.username as creator_name,
                   (SELECT COUNT(*) FROM playlist_tracks WHERE playlist_id = p.id) as track_count
            FROM playlists p
            LEFT JOIN users u ON p.created_by = u.id
            {$where}
            ORDER BY p.created_at DESC
        ");
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
    
    public static function getById($id) {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("
            SELECT p.*, u.username as creator_name,
                   (SELECT COUNT(*) FROM playlist_tracks WHERE playlist_id = p.id) as track_count
            FROM playlists p
            LEFT JOIN users u ON p.created_by = u.id
            WHERE p.id = ?
        ");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }
    
    public static function getTracks($playlistId) {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("
            SELECT pt.*, t.filename, t.filepath, t.title, t.artist, t.album, t.duration, t.filesize
            FROM playlist_tracks pt
            JOIN tracks t ON pt.track_id = t.id
            WHERE pt.playlist_id = ?
            ORDER BY pt.position ASC
        ");
        $stmt->execute([$playlistId]);
        return $stmt->fetchAll();
    }
    
    public static function create($name, $description, $userId) {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("
            INSERT INTO playlists (name, description, created_by)
            VALUES (?, ?, ?)
        ");
        $stmt->execute([$name, $description, $userId]);
        return ['success' => true, 'playlist_id' => $db->lastInsertId()];
    }
    
    public static function update($id, $name, $description) {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("
            UPDATE playlists SET name = ?, description = ? WHERE id = ?
        ");
        $stmt->execute([$name, $description, $id]);
        return ['success' => true];
    }
    
    public static function delete($id) {
        $db = Database::getInstance()->getConnection();
        // playlist_tracks deleted via CASCADE
        $db->prepare("DELETE FROM playlists WHERE id = ?")->execute([$id]);
        return ['success' => true];
    }
    
    public static function toggleActive($id) {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("SELECT is_active FROM playlists WHERE id = ?");
        $stmt->execute([$id]);
        $playlist = $stmt->fetch();
        
        $newStatus = $playlist['is_active'] ? 0 : 1;
        $db->prepare("UPDATE playlists SET is_active = ? WHERE id = ?")->execute([$newStatus, $id]);
        
        rebuildMainPlaylist();
        return ['success' => true, 'is_active' => $newStatus];
    }
    
    public static function addTrack($playlistId, $trackId) {
        $db = Database::getInstance()->getConnection();
        
        // Get next position
        $stmt = $db->prepare("SELECT MAX(position) as max_pos FROM playlist_tracks WHERE playlist_id = ?");
        $stmt->execute([$playlistId]);
        $result = $stmt->fetch();
        $position = ($result['max_pos'] ?? 0) + 1;
        
        try {
            $stmt = $db->prepare("
                INSERT INTO playlist_tracks (playlist_id, track_id, position)
                VALUES (?, ?, ?)
            ");
            $stmt->execute([$playlistId, $trackId, $position]);
            
            rebuildMainPlaylist();
            return ['success' => true];
        } catch (PDOException $e) {
            return ['success' => false, 'error' => 'Track already in playlist'];
        }
    }
    
    public static function removeTrack($playlistId, $trackId) {
        $db = Database::getInstance()->getConnection();
        $db->prepare("DELETE FROM playlist_tracks WHERE playlist_id = ? AND track_id = ?")
           ->execute([$playlistId, $trackId]);
        
        // Reorder positions
        $stmt = $db->prepare("SELECT id, position FROM playlist_tracks WHERE playlist_id = ? ORDER BY position ASC");
        $stmt->execute([$playlistId]);
        $tracks = $stmt->fetchAll();
        
        $pos = 1;
        foreach ($tracks as $t) {
            $db->prepare("UPDATE playlist_tracks SET position = ? WHERE id = ?")->execute([$pos, $t['id']]);
            $pos++;
        }
        
        rebuildMainPlaylist();
        return ['success' => true];
    }
    
    public static function reorderTrack($playlistId, $trackId, $newPosition) {
        $db = Database::getInstance()->getConnection();
        
        $db->beginTransaction();
        
        // Get current position
        $stmt = $db->prepare("SELECT position FROM playlist_tracks WHERE playlist_id = ? AND track_id = ?");
        $stmt->execute([$playlistId, $trackId]);
        $current = $stmt->fetch();
        
        if (!$current) {
            $db->rollBack();
            return ['success' => false, 'error' => 'Track not found in playlist'];
        }
        
        $oldPosition = $current['position'];
        
        if ($newPosition < $oldPosition) {
            $db->prepare("UPDATE playlist_tracks SET position = position + 1 WHERE playlist_id = ? AND position >= ? AND position < ?")
               ->execute([$playlistId, $newPosition, $oldPosition]);
        } else {
            $db->prepare("UPDATE playlist_tracks SET position = position - 1 WHERE playlist_id = ? AND position > ? AND position <= ?")
               ->execute([$playlistId, $oldPosition, $newPosition]);
        }
        
        $db->prepare("UPDATE playlist_tracks SET position = ? WHERE playlist_id = ? AND track_id = ?")
           ->execute([$newPosition, $playlistId, $trackId]);
        
        $db->commit();
        rebuildMainPlaylist();
        return ['success' => true];
    }
    
    public static function incrementPlayCount($playlistId) {
        $db = Database::getInstance()->getConnection();
        $db->prepare("UPDATE playlists SET play_count = play_count + 1 WHERE id = ?")->execute([$playlistId]);
    }
}