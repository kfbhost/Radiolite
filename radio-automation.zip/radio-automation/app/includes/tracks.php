<?php
/**
 * RadioLite - Track Management
 */
class TrackManager {
    
    public static function getAll($search = '', $offset = 0, $limit = 50) {
        $db = Database::getInstance()->getConnection();
        
        $where = '';
        $params = [];
        
        if (!empty($search)) {
            $search = '%' . $search . '%';
            $where = "WHERE (t.title LIKE ? OR t.artist LIKE ? OR t.album LIKE ? OR t.filename LIKE ?)";
            $params = [$search, $search, $search, $search];
        }
        
        $stmt = $db->prepare("
            SELECT t.*, 
                   (SELECT COUNT(*) FROM playlist_tracks WHERE track_id = t.id) as playlist_count
            FROM tracks t
            {$where}
            ORDER BY t.artist ASC, t.title ASC
            LIMIT ? OFFSET ?
        ");
        
        $params[] = $limit;
        $params[] = $offset;
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
    
    public static function getCount($search = '') {
        $db = Database::getInstance()->getConnection();
        
        $where = '';
        $params = [];
        
        if (!empty($search)) {
            $search = '%' . $search . '%';
            $where = "WHERE (title LIKE ? OR artist LIKE ? OR album LIKE ? OR filename LIKE ?)";
            $params = [$search, $search, $search, $search];
        }
        
        $stmt = $db->prepare("SELECT COUNT(*) as count FROM tracks {$where}");
        $stmt->execute($params);
        $result = $stmt->fetch();
        return $result['count'];
    }
    
    public static function getById($id) {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("SELECT * FROM tracks WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }
    
    public static function upload($file) {
        $errors = [];
        
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return ['success' => false, 'error' => 'Upload failed with error code: ' . $file['error']];
        }
        
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($extension, Config::ALLOWED_EXTENSIONS)) {
            return ['success' => false, 'error' => 'File type not allowed. Allowed: ' . implode(', ', Config::ALLOWED_EXTENSIONS)];
        }
        
        if ($file['size'] > Config::MAX_UPLOAD_SIZE) {
            return ['success' => false, 'error' => 'File too large. Max size: ' . formatBytes(Config::MAX_UPLOAD_SIZE)];
        }
        
        $filename = bin2hex(random_bytes(16)) . '.' . $extension;
        $filepath = Config::MUSIC_DIR . '/' . $filename;
        
        if (!move_uploaded_file($file['tmp_name'], $filepath)) {
            return ['success' => false, 'error' => 'Failed to move uploaded file'];
        }
        
        chmod($filepath, 0644);
        
        // Extract metadata
        $metadata = getAudioMetadata($filepath);
        
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("
            INSERT INTO tracks (filename, filepath, title, artist, album, genre, year, duration, bitrate, filesize, upload_user_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $file['name'],
            $filepath,
            $metadata['title'] ?: pathinfo($file['name'], PATHINFO_FILENAME),
            $metadata['artist'] ?: 'Unknown Artist',
            $metadata['album'] ?: '',
            $metadata['genre'] ?: '',
            $metadata['year'] ?: null,
            $metadata['duration'],
            $metadata['bitrate'],
            $file['size'],
            $_SESSION['user_id'] ?? null
        ]);
        
        $trackId = $db->lastInsertId();
        
        // Rebuild main playlist
        rebuildMainPlaylist();
        
        return [
            'success' => true,
            'track_id' => $trackId,
            'metadata' => $metadata
        ];
    }
    
    public static function bulkUpload($files) {
        $results = ['success' => [], 'failed' => []];
        
        foreach ($files['name'] as $i => $name) {
            $file = [
                'name' => $files['name'][$i],
                'type' => $files['type'][$i],
                'tmp_name' => $files['tmp_name'][$i],
                'error' => $files['error'][$i],
                'size' => $files['size'][$i]
            ];
            
            $result = self::upload($file);
            if ($result['success']) {
                $results['success'][] = $file['name'];
            } else {
                $results['failed'][] = ['file' => $file['name'], 'error' => $result['error']];
            }
        }
        
        return $results;
    }
    
    public static function delete($id) {
        $db = Database::getInstance()->getConnection();
        $track = self::getById($id);
        
        if (!$track) return ['success' => false, 'error' => 'Track not found'];
        
        // Delete file
        if (file_exists($track['filepath'])) {
            unlink($track['filepath']);
        }
        
        // Remove from playlists
        $db->prepare("DELETE FROM playlist_tracks WHERE track_id = ?")->execute([$id]);
        
        // Delete from database
        $db->prepare("DELETE FROM tracks WHERE id = ?")->execute([$id]);
        
        rebuildMainPlaylist();
        
        return ['success' => true];
    }
    
    public static function updateMetadata($id, $data) {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("
            UPDATE tracks SET title = ?, artist = ?, album = ?, genre = ?, year = ?
            WHERE id = ?
        ");
        $stmt->execute([
            $data['title'] ?? '',
            $data['artist'] ?? '',
            $data['album'] ?? '',
            $data['genre'] ?? '',
            $data['year'] ?? null,
            $id
        ]);
        
        return ['success' => true];
    }
    
    public static function scanDirectory($dir = null) {
        if ($dir === null) $dir = Config::MUSIC_DIR;
        
        $extensions = Config::ALLOWED_EXTENSIONS;
        $added = 0;
        $skipped = 0;
        
        $db = Database::getInstance()->getConnection();
        
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir));
        
        foreach ($iterator as $file) {
            if (!$file->isFile()) continue;
            
            $ext = strtolower($file->getExtension());
            if (!in_array($ext, $extensions)) continue;
            
            $filepath = $file->getPathname();
            
            // Check if already in database
            $stmt = $db->prepare("SELECT id FROM tracks WHERE filepath = ?");
            $stmt->execute([$filepath]);
            if ($stmt->fetch()) {
                $skipped++;
                continue;
            }
            
            $metadata = getAudioMetadata($filepath);
            
            $db->prepare("
                INSERT INTO tracks (filename, filepath, title, artist, album, genre, year, duration, bitrate, filesize)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ")->execute([
                $file->getFilename(),
                $filepath,
                $metadata['title'] ?: $file->getBasename('.' . $ext),
                $metadata['artist'] ?: 'Unknown Artist',
                $metadata['album'] ?: '',
                $metadata['genre'] ?: '',
                $metadata['year'] ?: null,
                $metadata['duration'],
                $metadata['bitrate'],
                $file->getSize()
            ]);
            
            $added++;
        }
        
        rebuildMainPlaylist();
        
        return ['added' => $added, 'skipped' => $skipped];
    }
}