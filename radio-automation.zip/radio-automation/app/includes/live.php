<?php
/**
 * RadioLite - Live DJ Takeover System
 */
class LiveTakeover {
    
    private static $lockFile = '/tmp/radiolite-live.lock';
    
    public static function requestTakeover($userId) {
        $db = Database::getInstance()->getConnection();
        $user = UserManager::getById($userId);
        
        if (!$user) {
            return ['success' => false, 'error' => 'User not found'];
        }
        
        // Create DJ session
        $token = Auth::createDJSession($userId, $_SERVER['REMOTE_ADDR']);
        
        // Create lock file to signal AutoDJ to pause
        $lockData = [
            'user_id' => $userId,
            'username' => $user['username'],
            'token' => $token,
            'started' => time(),
            'pid' => getAutoDJPID()
        ];
        
        file_put_contents(self::$lockFile, json_encode($lockData));
        
        // Stop AutoDJ temporarily
        self::pauseAutoDJ();
        
        return [
            'success' => true,
            'token' => $token,
            'icecast_settings' => Config::getStreamSettings()
        ];
    }
    
    public static function endTakeover($token) {
        $session = Auth::validateDJSession($token);
        
        if (!$session) {
            return ['success' => false, 'error' => 'Invalid session'];
        }
        
        // End the DJ session
        Auth::endDJSession($session['id']);
        
        // Remove lock file
        if (file_exists(self::$lockFile)) {
            unlink(self::$lockFile);
        }
        
        // Resume AutoDJ
        self::resumeAutoDJ();
        
        return ['success' => true];
    }
    
    public static function isLiveActive() {
        if (file_exists(self::$lockFile)) {
            $data = json_decode(file_get_contents(self::$lockFile), true);
            if ($data) {
                // Check if session is still valid
                $session = Auth::validateDJSession($data['token']);
                if ($session) {
                    return [
                        'active' => true,
                        'dj' => $data['username'],
                        'user_id' => $data['user_id'],
                        'started' => $data['started']
                    ];
                }
            }
            // Stale lock, clean up
            unlink(self::$lockFile);
            self::resumeAutoDJ();
        }
        
        return ['active' => false];
    }
    
    public static function pauseAutoDJ() {
        $pid = getAutoDJPID();
        if ($pid) {
            // Send SIGSTOP to pause the process
            @posix_kill($pid, SIGSTOP);
            return true;
        }
        return false;
    }
    
    public static function resumeAutoDJ() {
        // Check if there's still a live session
        if (self::isLiveActive()['active']) {
            return false; // Don't resume while live
        }
        
        $pid = getAutoDJPID();
        if ($pid) {
            // Send SIGCONT to resume the process
            @posix_kill($pid, SIGCONT);
            return true;
        } else {
            // AutoDJ not running, start it
            return startAutoDJ();
        }
    }
    
    public static function getIcecastSourcePassword() {
        $settings = Config::getStreamSettings();
        return $settings['icecast_password'] ?? 'hackme';
    }
    
    public static function getIcecastMount() {
        $settings = Config::getStreamSettings();
        return $settings['icecast_mount'] ?? '/stream';
    }
    
    public static function getIcecastHost() {
        $settings = Config::getStreamSettings();
        return $settings['icecast_host'] ?? 'localhost';
    }
    
    public static function getIcecastPort() {
        $settings = Config::getStreamSettings();
        return $settings['icecast_port'] ?? 8000;
    }
}