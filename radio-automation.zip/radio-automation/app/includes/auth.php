<?php
/**
 * RadioLite - Authentication System
 */
class Auth {
    
    public static function startSession() {
        if (session_status() === PHP_SESSION_NONE) {
            session_name(Config::SESSION_NAME);
            session_set_cookie_params([
                'lifetime' => Config::SESSION_DURATION,
                'path' => '/',
                'secure' => isset($_SERVER['HTTPS']),
                'httponly' => true,
                'samesite' => 'Strict'
            ]);
            session_start();
        }
    }
    
    public static function login($username, $password) {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("SELECT * FROM users WHERE username = ? AND is_active = 1");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
            self::startSession();
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['force_password_change'] = (bool)$user['force_password_change'];
            
            // Update last login
            $db->prepare("UPDATE users SET last_login = datetime('now') WHERE id = ?")
               ->execute([$user['id']]);
            
            return true;
        }
        return false;
    }
    
    public static function logout() {
        self::startSession();
        // Clear DJ session if exists
        if (isset($_SESSION['dj_session_id'])) {
            self::endDJSession($_SESSION['dj_session_id']);
        }
        $_SESSION = [];
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        session_destroy();
    }
    
    public static function isLoggedIn() {
        self::startSession();
        return isset($_SESSION['user_id']);
    }
    
    public static function getUser() {
        self::startSession();
        if (!isset($_SESSION['user_id'])) return null;
        return [
            'id' => $_SESSION['user_id'],
            'username' => $_SESSION['username'],
            'role' => $_SESSION['role'],
            'force_password_change' => $_SESSION['force_password_change']
        ];
    }
    
    public static function requireLogin() {
        if (!self::isLoggedIn()) {
            header('Location: /login.php');
            exit;
        }
    }
    
    public static function requireAdmin() {
        self::requireLogin();
        $user = self::getUser();
        if ($user['role'] !== 'admin') {
            http_response_code(403);
            exit('Access denied');
        }
    }
    
    public static function requireDJ() {
        self::requireLogin();
        $user = self::getUser();
        if (!in_array($user['role'], ['admin', 'dj'])) {
            http_response_code(403);
            exit('Access denied');
        }
    }
    
    public static function changePassword($userId, $oldPassword, $newPassword) {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        
        if (!$user || !password_verify($oldPassword, $user['password'])) {
            return ['success' => false, 'error' => 'Current password is incorrect'];
        }
        
        if (strlen($newPassword) < 8) {
            return ['success' => false, 'error' => 'Password must be at least 8 characters'];
        }
        
        $hash = password_hash($newPassword, PASSWORD_BCRYPT);
        $db->prepare("UPDATE users SET password = ?, force_password_change = 0 WHERE id = ?")
           ->execute([$hash, $userId]);
        
        return ['success' => true];
    }
    
    public static function createDJSession($userId, $ipAddress) {
        $db = Database::getInstance()->getConnection();
        $token = bin2hex(random_bytes(32));
        $db->prepare("INSERT INTO dj_sessions (user_id, session_token, ip_address) VALUES (?, ?, ?)")
           ->execute([$userId, $token, $ipAddress]);
        return $token;
    }
    
    public static function endDJSession($sessionId) {
        $db = Database::getInstance()->getConnection();
        $db->prepare("UPDATE dj_sessions SET disconnected_at = datetime('now'), is_active = 0 WHERE id = ?")
           ->execute([$sessionId]);
    }
    
    public static function validateDJSession($token) {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("SELECT * FROM dj_sessions WHERE session_token = ? AND is_active = 1");
        $stmt->execute([$token]);
        return $stmt->fetch();
    }
}