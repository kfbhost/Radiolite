<?php
/**
 * RadioLite - Helper Functions
 */

function redirect($url) {
    header("Location: $url");
    exit;
}

function jsonResponse($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

function formatDuration($seconds) {
    if ($seconds <= 0) return '--:--';
    $minutes = floor($seconds / 60);
    $secs = floor($seconds % 60);
    return sprintf('%d:%02d', $minutes, $secs);
}

function formatBytes($bytes) {
    if ($bytes >= 1073741824) return round($bytes / 1073741824, 2) . ' GB';
    if ($bytes >= 1048576) return round($bytes / 1048576, 2) . ' MB';
    if ($bytes >= 1024) return round($bytes / 1024, 2) . ' KB';
    return $bytes . ' B';
}

function getAudioMetadata($filepath) {
    $metadata = [
        'title' => '',
        'artist' => '',
        'album' => '',
        'genre' => '',
        'year' => null,
        'duration' => 0,
        'bitrate' => 0
    ];
    
    $ffprobe = '/usr/bin/ffprobe';
    if (!file_exists($ffprobe)) {
        $ffprobe = 'ffprobe';
    }
    
    $cmd = sprintf(
        '%s -v quiet -print_format json -show_format -show_streams %s 2>/dev/null',
        escapeshellcmd($ffprobe),
        escapeshellarg($filepath)
    );
    
    $output = shell_exec($cmd);
    if (!$output) return $metadata;
    
    $info = json_decode($output, true);
    if (!$info) return $metadata;
    
    // Extract format info
    if (isset($info['format'])) {
        $fmt = $info['format'];
        $metadata['duration'] = isset($fmt['duration']) ? (float)$fmt['duration'] : 0;
        
        // Parse tags
        if (isset($fmt['tags'])) {
            $tags = $fmt['tags'];
            $metadata['title'] = $tags['title'] ?? $tags['TIT2'] ?? '';
            $metadata['artist'] = $tags['artist'] ?? $tags['TPE1'] ?? '';
            $metadata['album'] = $tags['album'] ?? $tags['TALB'] ?? '';
            $metadata['genre'] = $tags['genre'] ?? $tags['TCON'] ?? '';
            $metadata['year'] = $tags['date'] ?? $tags['TYER'] ?? $tags['TDRC'] ?? null;
        }
    }
    
    // Extract bitrate from audio stream
    if (isset($info['streams'])) {
        foreach ($info['streams'] as $stream) {
            if ($stream['codec_type'] === 'audio') {
                $metadata['bitrate'] = $stream['bit_rate'] ?? 0;
                break;
            }
        }
    }
    
    return $metadata;
}

function getNowPlaying() {
    $db = Database::getInstance()->getConnection();
    $stmt = $db->query("SELECT * FROM now_playing ORDER BY started_at DESC LIMIT 1");
    return $stmt->fetch() ?: null;
}

function updateNowPlaying($trackId, $title, $artist) {
    $db = Database::getInstance()->getConnection();
    $db->exec("DELETE FROM now_playing");
    $stmt = $db->prepare("INSERT INTO now_playing (track_id, title, artist) VALUES (?, ?, ?)");
    $stmt->execute([$trackId, $title, $artist]);
}

function getIcecastStatus() {
    $settings = Config::getStreamSettings();
    $host = $settings['icecast_host'] ?? 'localhost';
    $port = $settings['icecast_port'] ?? 8000;
    $mount = $settings['icecast_mount'] ?? '/stream';
    
    $status = [
        'online' => false,
        'listeners' => 0,
        'max_listeners' => 0,
        'mount' => $mount,
        'bitrate' => 0
    ];
    
    $url = "http://{$host}:{$port}/admin/stats?mount={$mount}";
    $context = stream_context_create([
        'http' => [
            'timeout' => 5,
            'header' => "Authorization: Basic " . base64_encode("admin:" . ($settings['icecast_password'] ?? 'hackme'))
        ]
    ]);
    
    $response = @file_get_contents($url, false, $context);
    if ($response) {
        $xml = @simplexml_load_string($response);
        if ($xml) {
            $status['online'] = true;
            $status['listeners'] = (int)($xml->listeners ?? 0);
            $status['max_listeners'] = (int)($xml->max_listeners ?? 0);
            $status['bitrate'] = (int)($xml->bitrate ?? 0);
        }
    }
    
    return $status;
}

function isAutoDJRunning() {
    $output = shell_exec("pgrep -f 'liquidsoap.*autodj' 2>/dev/null");
    return !empty(trim($output));
}

function getAutoDJPID() {
    $pidFile = '/tmp/radiolite-autodj.pid';
    if (file_exists($pidFile)) {
        $pid = trim(file_get_contents($pidFile));
        if ($pid && posix_kill($pid, 0)) {
            return $pid;
        }
    }
    return null;
}

function startAutoDJ() {
    $settings = Config::getStreamSettings();
    $conf = Config::getIcecastConfig();
    
    $pid = getAutoDJPID();
    if ($pid) return ['success' => false, 'error' => 'AutoDJ already running (PID: ' . $pid . ')'];
    
    $cmd = "nohup liquidsoap " . Config::LIQUIDSOAP_SCRIPT . " >> " . Config::LOG_DIR . "/autodj.log 2>&1 &";
    shell_exec($cmd);
    usleep(500000);
    
    $pid = getAutoDJPID();
    if ($pid) {
        return ['success' => true, 'pid' => $pid];
    }
    return ['success' => false, 'error' => 'Failed to start AutoDJ'];
}

function stopAutoDJ() {
    $pid = getAutoDJPID();
    if (!$pid) return ['success' => true, 'message' => 'AutoDJ not running'];
    
    posix_kill($pid, SIGTERM);
    sleep(1);
    
    if (posix_kill($pid, 0)) {
        posix_kill($pid, SIGKILL);
    }
    
    return ['success' => true, 'message' => 'AutoDJ stopped'];
}

function restartAutoDJ() {
    stopAutoDJ();
    sleep(1);
    return startAutoDJ();
}

function generateM3U($playlistId) {
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare("
        SELECT t.filepath, t.title, t.artist 
        FROM playlist_tracks pt 
        JOIN tracks t ON pt.track_id = t.id 
        WHERE pt.playlist_id = ? AND t.is_active = 1 
        ORDER BY pt.position ASC
    ");
    $stmt->execute([$playlistId]);
    $tracks = $stmt->fetchAll();
    
    $m3u = "#EXTM3U\n";
    foreach ($tracks as $track) {
        $m3u .= "#EXTINF:-1,{$track['artist']} - {$track['title']}\n";
        $m3u .= $track['filepath'] . "\n";
    }
    
    return $m3u;
}

function rebuildMainPlaylist() {
    $db = Database::getInstance()->getConnection();
    
    // Get active playlists ordered by play_count (least played first)
    $stmt = $db->query("SELECT id FROM playlists WHERE is_active = 1 ORDER BY play_count ASC");
    $playlists = $stmt->fetchAll();
    
    $allTracks = [];
    foreach ($playlists as $pl) {
        $stmt = $db->prepare("
            SELECT t.filepath, t.title, t.artist, pt.position 
            FROM playlist_tracks pt 
            JOIN tracks t ON pt.track_id = t.id 
            WHERE pt.playlist_id = ? AND t.is_active = 1 
            ORDER BY pt.position ASC
        ");
        $stmt->execute([$pl['id']]);
        $tracks = $stmt->fetchAll();
        $allTracks = array_merge($allTracks, $tracks);
    }
    
    // Shuffle for random playback
    shuffle($allTracks);
    
    $m3u = "#EXTM3U\n";
    foreach ($allTracks as $track) {
        $m3u .= "#EXTINF:-1,{$track['artist']} - {$track['title']}\n";
        $m3u .= $track['filepath'] . "\n";
    }
    
    file_put_contents(Config::MUSIC_DIR . '/main.m3u', $m3u);
    return count($allTracks);
}