<?php
/**
 * RadioLite - AutoDJ Engine
 */
class AutoDJ {
    
    public static function getStatus() {
        $pid = getAutoDJPID();
        $icecastStatus = getIcecastStatus();
        
        return [
            'running' => $pid !== null,
            'pid' => $pid,
            'icecast_online' => $icecastStatus['online'],
            'listeners' => $icecastStatus['listeners'],
            'max_listeners' => $icecastStatus['max_listeners'],
            'bitrate' => $icecastStatus['bitrate'],
            'mount' => $icecastStatus['mount'],
            'live_source' => self::detectLiveSource()
        ];
    }
    
    public static function start() {
        if (getAutoDJPID()) {
            return ['success' => false, 'error' => 'AutoDJ is already running'];
        }
        
        $settings = Config::getStreamSettings();
        self::generateLiquidsoapConfig($settings);
        
        $pid = startAutoDJ();
        if ($pid) {
            return ['success' => true, 'pid' => $pid];
        }
        return ['success' => false, 'error' => 'Failed to start AutoDJ'];
    }
    
    public static function stop() {
        $result = stopAutoDJ();
        return $result;
    }
    
    public static function restart() {
        $result = restartAutoDJ();
        return $result;
    }
    
    public static function detectLiveSource() {
        $settings = Config::getStreamSettings();
        $host = $settings['icecast_host'] ?? 'localhost';
        $port = $settings['icecast_port'] ?? 8000;
        $mount = $settings['icecast_mount'] ?? '/stream';
        
        $url = "http://{$host}:{$port}/admin/stats?mount={$mount}";
        $context = stream_context_create([
            'http' => [
                'timeout' => 3,
                'header' => "Authorization: Basic " . base64_encode("admin:" . ($settings['icecast_password'] ?? 'hackme'))
            ]
        ]);
        
        $response = @file_get_contents($url, false, $context);
        if ($response) {
            $xml = @simplexml_load_string($response);
            if ($xml) {
                $sourceType = (string)($xml->source_type ?? '');
                $listenerCount = (int)($xml->listeners ?? 0);
                
                if ($sourceType && $listenerCount > 0) {
                    return [
                        'active' => true,
                        'type' => $sourceType,
                        'listeners' => $listenerCount
                    ];
                }
            }
        }
        
        return ['active' => false];
    }
    
    public static function generateLiquidsoapConfig($settings = null) {
        if ($settings === null) {
            $settings = Config::getStreamSettings();
        }
        
        $port = $settings['icecast_port'] ?? 8000;
        $mount = $settings['icecast_mount'] ?? '/stream';
        $password = $settings['icecast_password'] ?? 'hackme';
        $host = $settings['icecast_host'] ?? 'localhost';
        $format = $settings['format'] ?? 'mp3';
        $bitrate = $settings['bitrate'] ?? 128;
        $samplerate = $settings['samplerate'] ?? 44100;
        $channels = $settings['channels'] ?? 2;
        
        $streamName = str_replace("'", "\\'", $settings['stream_name'] ?? 'RadioLite');
        $genre = str_replace("'", "\\'", $settings['stream_genre'] ?? 'Various');
        $description = str_replace("'", "\\'", $settings['stream_description'] ?? 'RadioLite Internet Radio');
        $url = str_replace("'", "\\'", $settings['stream_url'] ?? 'http://localhost');
        
        $audioFormat = ($format === 'ogg') ? '%vorbis' : '%mp3';
        if ($format === 'aac') $audioFormat = '%fdkaac';
        
        $playlistPath = Config::MAIN_PLAYLIST;
        
        $script = <<<LIQ
#!/usr/bin/liquidsoap
# RadioLite AutoDJ Engine - Auto-generated
set("init.daemon", true)
set("init.daemon.pidfile.path", "/tmp/radiolite-autodj.pid")
set("log.file.path", "/opt/radiolite/logs/liquidsoap.log")
set("log.stdout", true)
set("log.level", 3)
set("harbor.bind_addr", "0.0.0.0")

blank = blank(id="blank")

request_queue = audio_to_stereo(request.queue(
    id="live_queue",
    timeout=60.0,
    blank
))

def music_source() =
    audio_to_stereo(
        playlist(
            id="main_playlist",
            mode="random",
            reload_mode="watch",
            "{$playlistPath}"
        )
    )

radio = fallback(
    id="main_switch",
    track_sensitive=false,
    [request_queue, music_source()]
)

radio = amplify(1.0, radio)

output.icecast(
    {$audioFormat}(stereo, samplerate={$samplerate}, bitrate={$bitrate}),
    host = "{$host}",
    port = {$port},
    password = "{$password}",
    mount = "{$mount}",
    name = "{$streamName}",
    genre = "{$genre}",
    description = "{$description}",
    url = "{$url}",
    radio
)
LIQ;
        
        @mkdir(dirname(Config::LIQUIDSOAP_SCRIPT), 0755, true);
        file_put_contents(Config::LIQUIDSOAP_SCRIPT, $script);
        @chmod(Config::LIQUIDSOAP_SCRIPT, 0755);
        
        return true;
    }
    
    public static function getQueue() {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->query("
            SELECT dj.*, u.username
            FROM dj_sessions dj
            JOIN users u ON dj.user_id = u.id
            WHERE dj.is_active = 1
            ORDER BY dj.connected_at DESC
        ");
        return $stmt->fetchAll();
    }
}