<?php
/**
 * RadioLite - User/DJ Management
 */
class UserManager {
    
    public static function getAll() {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->query("
            SELECT u.*, 
                   (SELECT COUNT(*) FROM dj_sessions WHERE user_id = u.id AND is_active = 1) as active_sessions
            FROM users u
            ORDER BY u.role DESC, u.username ASC
        ");
        return $stmt->fetchAll();
    }
    
    public static function getById($id) {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }
    
    public static function getByUsername($username) {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        return $stmt->fetch();
    }
    
    public static function create($username, $password, $email, $role = 'dj') {
        $db = Database::getInstance()->getConnection();
        
        // Check if username exists
        $stmt = $db->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            return ['success' => false, 'error' => 'Username already exists'];
        }
        
        $hash = password_hash($password, PASSWORD_BCRYPT);
        
        try {
            $stmt = $db->prepare("
                INSERT INTO users (username, password, email, role)
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([$username, $hash, $email, $role]);
            return ['success' => true, 'user_id' => $db->lastInsertId()];
        } catch (PDOException $e) {
            return ['success' => false, 'error' => 'Database error: ' . $e->getMessage()];
        }
    }
    
    public static function update($id, $data) {
        $db = Database::getInstance()->getConnection();
        
        $fields = [];
        $params = [];
        
        if (isset($data['email'])) { $fields[] = "email = ?"; $params[] = $data['email']; }
        if (isset($data['role'])) { $fields[] = "role = ?"; $params[] = $data['role']; }
        if (isset($data['is_active'])) { $fields[] = "is_active = ?"; $params[] = $data['is_active']; }
        
        if (empty($fields)) return ['success' => true];
        
        $params[] = $id;
        $sql = "UPDATE users SET " . implode(', ', $fields) . " WHERE id = ?";
        $db->prepare($sql)->execute($params);
        
        return ['success' => true];
    }
    
    public static function delete($id) {
        $db = Database::getInstance()->getConnection();
        // Don't allow deleting the last admin
        $stmt = $db->prepare("SELECT role FROM users WHERE id = ?");
        $stmt->execute([$id]);
        $user = $stmt->fetch();
        
        if ($user && $user['role'] === 'admin') {
            $adminCount = $db->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn();
            if ($adminCount <= 1) {
                return ['success' => false, 'error' => 'Cannot delete the last admin'];
            }
        }
        
        $db->prepare("DELETE FROM users WHERE id = ?")->execute([$id]);
        return ['success' => true];
    }
    
    public static function toggleActive($id) {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("SELECT is_active FROM users WHERE id = ?");
        $stmt->execute([$id]);
        $user = $stmt->fetch();
        
        $newStatus = $user['is_active'] ? 0 : 1;
        $db->prepare("UPDATE users SET is_active = ? WHERE id = ?")->execute([$newStatus, $id]);
        
        return ['success' => true, 'is_active' => $newStatus];
    }
    
    public static function getActiveDJs() {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->query("
            SELECT u.id, u.username, u.role, ds.connected_at, ds.ip_address
            FROM users u
            JOIN dj_sessions ds ON u.id = ds.user_id
            WHERE ds.is_active = 1 AND u.is_active = 1
            ORDER BY ds.connected_at DESC
        ");
        return $stmt->fetchAll();
    }
    
    public static function getDJCount() {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->query("SELECT COUNT(*) FROM users WHERE role = 'dj' AND is_active = 1");
        return $stmt->fetchColumn();
    }
}