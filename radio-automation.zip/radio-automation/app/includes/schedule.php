<?php
/**
 * RadioLite - Schedule Management
 */
class ScheduleManager {
    
    public static function getAll() {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->query("
            SELECT s.*, p.name as playlist_name, u.username as creator_name
            FROM schedule s
            LEFT JOIN playlists p ON s.playlist_id = p.id
            LEFT JOIN users u ON p.created_by = u.id
            ORDER BY s.day_of_week ASC, s.start_time ASC
        ");
        return $stmt->fetchAll();
    }
    
    public static function getByDay($day) {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("
            SELECT s.*, p.name as playlist_name
            FROM schedule s
            LEFT JOIN playlists p ON s.playlist_id = p.id
            WHERE s.day_of_week = ? AND s.is_active = 1
            ORDER BY s.start_time ASC
        ");
        $stmt->execute([$day]);
        return $stmt->fetchAll();
    }
    
    public static function getCurrentPlaylist() {
        $dayOfWeek = date('l');
        $currentTime = date('H:i');
        
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("
            SELECT s.*, p.name as playlist_name
            FROM schedule s
            LEFT JOIN playlists p ON s.playlist_id = p.id
            WHERE s.day_of_week = ? AND s.is_active = 1
            AND s.start_time <= ? AND s.end_time > ?
            LIMIT 1
        ");
        $stmt->execute([$dayOfWeek, $currentTime, $currentTime]);
        return $stmt->fetch();
    }
    
    public static function create($playlistId, $dayOfWeek, $startTime, $endTime) {
        $db = Database::getInstance()->getConnection();
        
        // Validate day
        $validDays = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
        if (!in_array($dayOfWeek, $validDays)) {
            return ['success' => false, 'error' => 'Invalid day of week'];
        }
        
        // Validate time format
        if (!preg_match('/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/', $startTime) ||
            !preg_match('/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/', $endTime)) {
            return ['success' => false, 'error' => 'Invalid time format. Use HH:MM'];
        }
        
        try {
            $stmt = $db->prepare("
                INSERT INTO schedule (playlist_id, day_of_week, start_time, end_time)
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([$playlistId, $dayOfWeek, $startTime, $endTime]);
            return ['success' => true, 'schedule_id' => $db->lastInsertId()];
        } catch (PDOException $e) {
            return ['success' => false, 'error' => 'Schedule conflict or database error'];
        }
    }
    
    public static function delete($id) {
        $db = Database::getInstance()->getConnection();
        $db->prepare("DELETE FROM schedule WHERE id = ?")->execute([$id]);
        return ['success' => true];
    }
    
    public static function toggleActive($id) {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("SELECT is_active FROM schedule WHERE id = ?");
        $stmt->execute([$id]);
        $schedule = $stmt->fetch();
        
        $newStatus = $schedule['is_active'] ? 0 : 1;
        $db->prepare("UPDATE schedule SET is_active = ? WHERE id = ?")->execute([$newStatus, $id]);
        
        return ['success' => true, 'is_active' => $newStatus];
    }
    
    public static function getActiveSchedules() {
        $db = Database::getInstance()->getConnection();
        $dayOfWeek = date('l');
        $currentTime = date('H:i');
        
        $stmt = $db->prepare("
            SELECT s.*, p.name as playlist_name, p.id as playlist_id
            FROM schedule s
            JOIN playlists p ON s.playlist_id = p.id
            WHERE s.day_of_week = ? AND s.is_active = 1 AND p.is_active = 1
            AND s.start_time <= ? AND s.end_time > ?
        ");
        $stmt->execute([$dayOfWeek, $currentTime, $currentTime]);
        return $stmt->fetchAll();
    }
}