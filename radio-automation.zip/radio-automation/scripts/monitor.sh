#!/bin/bash
# RadioLite - System Monitor Script
# Monitors AutoDJ and restarts if crashed

LOG_FILE="/opt/radiolite/logs/monitor.log"
PID_FILE="/tmp/radiolite-autodj.pid"
LIQUIDSOAP_SCRIPT="/opt/radiolite/scripts/autodj.liq"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

# Check if Liquidsoap is running
check_autodj() {
    if [ -f "$PID_FILE" ]; then
        PID=$(cat "$PID_FILE")
        if kill -0 "$PID" 2>/dev/null; then
            return 0
        fi
    fi
    return 1
}

# Check if Icecast is running
check_icecast() {
    pgrep -x "icecast2" > /dev/null 2>&1
    return $?
}

# Start AutoDJ
start_autodj() {
    log_message "Starting AutoDJ..."
    cd /opt/radiolite
    nohup liquidsoap "$LIQUIDSOAP_SCRIPT" >> /opt/radiolite/logs/autodj.log 2>&1 &
    sleep 2
    
    if check_autodj; then
        log_message "AutoDJ started successfully (PID: $(cat $PID_FILE))"
    else
        log_message "ERROR: Failed to start AutoDJ"
    fi
}

# Start Icecast
start_icecast() {
    log_message "Starting Icecast2..."
    systemctl start icecast2 2>/dev/null || service icecast2 start 2>/dev/null
    sleep 2
    
    if check_icecast; then
        log_message "Icecast2 started successfully"
    else
        log_message "ERROR: Failed to start Icecast2"
    fi
}

# Main monitoring loop
log_message "Monitor started"

while true; do
    # Check AutoDJ
    if ! check_autodj; then
        log_message "WARNING: AutoDJ is not running. Restarting..."
        start_autodj
    fi
    
    # Check Icecast
    if ! check_icecast; then
        log_message "WARNING: Icecast2 is not running. Restarting..."
        start_icecast
    fi
    
    # Check if live source disconnected (resume AutoDJ)
    if [ -f "/tmp/radiolite-live.lock" ]; then
        LOCK_DATA=$(cat /tmp/radiolite-live.lock 2>/dev/null)
        if [ -n "$LOCK_DATA" ]; then
            TOKEN=$(echo "$LOCK_DATA" | python3 -c "import sys,json; print(json.load(sys.stdin).get('token',''))" 2>/dev/null)
            if [ -n "$TOKEN" ]; then
                # Check if session is still valid
                DB_PATH="/opt/radiolite/config/radiolite.db"
                VALID=$(sqlite3 "$DB_PATH" "SELECT COUNT(*) FROM dj_sessions WHERE session_token='$TOKEN' AND is_active=1;" 2>/dev/null)
                if [ "$VALID" = "0" ]; then
                    log_message "Live session ended. Resuming AutoDJ..."
                    rm -f /tmp/radiolite-live.lock
                    
                    # Resume stopped AutoDJ
                    PID=$(cat "$PID_FILE" 2>/dev/null)
                    if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then
                        kill -CONT "$PID" 2>/dev/null
                    else
                        start_autodj
                    fi
                fi
            fi
        fi
    fi
    
    sleep 10
done