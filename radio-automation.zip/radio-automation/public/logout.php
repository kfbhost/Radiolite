<?php
require_once __DIR__ . '/../app/config/db.php';
require_once __DIR__ . '/../app/config/config.php';
require_once __DIR__ . '/../app/includes/auth.php';

Auth::logout();
header('Location: /login.php');
exit;