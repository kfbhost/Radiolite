/**
 * RadioLite - Frontend Application
 */

const API = {
    base: '/api',
    
    async request(endpoint, method = 'GET', body = null, headers = {}) {
        const options = {
            method,
            headers: {
                'Content-Type': 'application/json',
                ...headers
            }
        };
        if (body) options.body = JSON.stringify(body);
        
        try {
            const res = await fetch(`${this.base}${endpoint}`, options);
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Request failed');
            return data;
        } catch (err) {
            if (err.message === 'Failed to fetch') {
                throw new Error('Network error - check connection');
            }
            throw err;
        }
    },
    
    get(endpoint) { return this.request(endpoint); },
    post(endpoint, body) { return this.request(endpoint, 'POST', body); },
    
    async formPost(endpoint, formData) {
        try {
            const res = await fetch(`${this.base}${endpoint}`, {
                method: 'POST',
                body: formData
            });
            return await res.json();
        } catch (err) {
            throw new Error('Network error');
        }
    }
};

const App = {
    currentPage: '',
    autoRefresh: null,
    refreshInterval: 5000,
    
    init() {
        this.setupNavigation();
        this.setupLogin();
        this.checkAuth();
    },
    
    checkAuth() {
        const token = localStorage.getItem('radiolite_token');
        if (!token && !window.location.pathname.includes('login') && !window.location.pathname.includes('change-password')) {
            window.location.href = '/login';
            return;
        }
        if (token) {
            API.base = '/api';
        }
    },
    
    setupNavigation() {
        document.addEventListener('click', (e) => {
            const navItem = e.target.closest('[data-page]');
            if (navItem) {
                e.preventDefault();
                const page = navItem.dataset.page;
                this.navigate(page);
            }
        });
    },
    
    navigate(page) {
        this.currentPage = page;
        
        document.querySelectorAll('[data-page]').forEach(el => {
            el.classList.toggle('active', el.dataset.page === page);
        });
        
        document.querySelectorAll('.page-section').forEach(el => {
            el.style.display = el.id === `page-${page}` ? 'block' : 'none';
        });
        
        this.loadPageData(page);
        history.pushState({ page }, '', `?page=${page}`);
    },
    
    async loadPageData(page) {
        try {
            switch (page) {
                case 'dashboard':
                    await this.loadDashboard();
                    break;
                case 'library':
                    await this.loadLibrary();
                    break;
                case 'playlists':
                    await this.loadPlaylists();
                    break;
                case 'upload':
                    break;
                case 'autodj':
                    await this.loadAutoDJ();
                    break;
                case 'schedule':
                    await this.loadSchedule();
                    break;
                case 'djs':
                    await this.loadDJs();
                    break;
                case 'settings':
                    await this.loadSettings();
                    break;
                case 'live':
                    await this.loadLive();
                    break;
            }
        } catch (err) {
            if (err.message.includes('401') || err.message.includes('login')) {
                window.location.href = '/login';
            } else {
                this.showAlert('error', err.message);
            }
        }
    },
    
    async loadDashboard() {
        const [status] = await Promise.all([
            API.get('/autodj?action=status')
        ]);
        
        const autodj = status.autodj;
        const np = status.now_playing;
        
        const npWidget = document.getElementById('np-widget');
        if (np && np.title) {
            npWidget.innerHTML = `
                <div class="now-playing-widget">
                    <div class="now-playing-art">🎵</div>
                    <div class="now-playing-info">
                        <h4>${this.esc(np.title)}</h4>
                        <p>${this.esc(np.artist || 'Unknown Artist')}</p>
                    </div>
                    ${autodj.live_source?.active ? '<span class="badge badge-live"><span class="live-dot"></span>LIVE</span>' : ''}
                </div>
            `;
        } else {
            npWidget.innerHTML = '<div class="empty-state"><div class="icon">🎵</div><p>No track playing</p></div>';
        }
        
        document.getElementById('stats-container').innerHTML = `
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon blue">📡</div>
                    <div class="stat-info">
                        <h4>AutoDJ Status</h4>
                        <div class="stat-value">${autodj.running ? '<span style="color:var(--accent-green)">● Running</span>' : '<span style="color:var(--accent-red)">● Stopped</span>'}</div>
                        <div class="stat-label">PID: ${autodj.pid || 'N/A'}</div>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon green">👥</div>
                    <div class="stat-info">
                        <h4>Current Listeners</h4>
                        <div class="stat-value">${autodj.listeners || 0}</div>
                        <div class="stat-label">Max: ${autodj.max_listeners || 0}</div>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon orange">📶</div>
                    <div class="stat-info">
                        <h4>Bitrate</h4>
                        <div class="stat-value">${autodj.bitrate || 0} kbps</div>
                        <div class="stat-label">Stream bitrate</div>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon purple">🎧</div>
                    <div class="stat-info">
                        <h4>Live DJ</h4>
                        <div class="stat-value">${autodj.live_source?.active ? '<span style="color:var(--accent-red)">● Active</span>' : '<span style="color:var(--text-muted)">Offline</span>'}</div>
                        <div class="stat-label">${autodj.live_source?.active ? this.esc(autodj.live_source.dj || 'Unknown') : 'No live source'}</div>
                    </div>
                </div>
            </div>
        `;
        
        const controlsHtml = `
            <div style="display:flex;gap:8px;margin-top:16px;flex-wrap:wrap;">
                <button class="btn btn-success btn-sm" onclick="App.startAutoDJ()" ${autodj.running ? 'disabled' : ''}>▶ Start AutoDJ</button>
                <button class="btn btn-warning btn-sm" onclick="App.restartAutoDJ()" ${!autodj.running ? 'disabled' : ''}>↻ Restart</button>
                <button class="btn btn-danger btn-sm" onclick="App.stopAutoDJ()" ${!autodj.running ? 'disabled' : ''}>■ Stop</button>
            </div>
        `;
        document.getElementById('autodj-controls').innerHTML = controlsHtml;
        
        // Track and playlist counts
        try {
            const tracks = await API.get('/tracks?action=list&page=1&search=');
            document.getElementById('track-count').textContent = tracks.total || 0;
        } catch(e) {}
    },
    
    async loadLibrary(page = 1, search = '') {
        const data = await API.get(`/tracks?action=list&page=${page}&search=${encodeURIComponent(search)}`);
        
        let html = `
            <div class="flex-between mb-20">
                <div style="flex:1;max-width:300px;">
                    <input type="text" class="form-control" id="search-tracks" placeholder="Search tracks..." 
                           value="${this.esc(search)}" oninput="App.searchTracks(this.value)">
                </div>
                <button class="btn btn-primary" onclick="document.getElementById('upload-modal').classList.add('active')">
                    + Upload Tracks
                </button>
            </div>
        `;
        
        if (data.tracks.length === 0) {
            html += `<div class="empty-state"><div class="icon">🎵</div><p>${search ? 'No tracks match your search' : 'No tracks uploaded yet. Click "Upload Tracks" to add music.'}</p></div>`;
        } else {
            html += `<div class="table-container"><table>
                <thead><tr>
                    <th>#</th><th>Title</th><th>Artist</th><th>Album</th><th>Genre</th>
                    <th>Duration</th><th>Size</th><th>Actions</th>
                </tr></thead><tbody>`;
            
            data.tracks.forEach((track, i) => {
                html += `<tr>
                    <td>${(page - 1) * 50 + i + 1}</td>
                    <td><strong>${this.esc(track.title || 'Unknown')}</strong></td>
                    <td>${this.esc(track.artist || 'Unknown')}</td>
                    <td>${this.esc(track.album || '-')}</td>
                    <td>${this.esc(track.genre || '-')}</td>
                    <td>${track.duration ? this.formatDuration(track.duration) : '--:--'}</td>
                    <td>${track.filesize ? this.formatBytes(track.filesize) : '-'}</td>
                    <td>
                        <div class="actions-group">
                            <button class="btn btn-sm btn-secondary" onclick="App.addTrackToPlaylist(${track.id})" title="Add to playlist">➕</button>
                            <button class="btn btn-sm btn-danger" onclick="App.deleteTrack(${track.id})" title="Delete">🗑️</button>
                        </div>
                    </td>
                </tr>`;
            });
            
            html += '</tbody></table></div>';
            
            if (data.pages > 1) {
                html += '<div style="display:flex;gap:4px;margin-top:16px;justify-content:center;">';
                for (let p = 1; p <= data.pages; p++) {
                    html += `<button class="btn btn-sm ${p === page ? 'btn-primary' : 'btn-secondary'}" onclick="App.loadLibrary(${p},'${search}')">${p}</button>`;
                }
                html += '</div>';
            }
        }
        
        document.getElementById('library-content').innerHTML = html;
    },
    
    searchTracks(query) {
        clearTimeout(this._searchTimer);
        this._searchTimer = setTimeout(() => this.loadLibrary(1, query), 300);
    },
    
    async addTrackToPlaylist(trackId) {
        const data = await API.get('/playlists?action=list');
        if (data.playlists.length === 0) {
            this.showAlert('warning', 'No playlists found. Create one first.');
            return;
        }
        const playlistId = prompt('Enter Playlist ID to add track to:', data.playlists[0].id);
        if (!playlistId) return;
        try {
            await API.post('/playlists?action=add_track', { playlist_id: parseInt(playlistId), track_id: trackId });
            this.showAlert('success', 'Track added to playlist!');
        } catch (err) {
            this.showAlert('error', err.message);
        }
    },
    
    async deleteTrack(id) {
        if (!confirm('Are you sure you want to delete this track?')) return;
        try {
            await API.post('/tracks?action=delete', { id });
            this.loadLibrary();
            this.showAlert('success', 'Track deleted');
        } catch (err) {
            this.showAlert('error', err.message);
        }
    },
    
    async loadPlaylists() {
        const data = await API.get('/playlists?action=list');
        
        let html = `
            <div class="flex-between mb-20">
                <h3>Playlists</h3>
                <button class="btn btn-primary" onclick="App.showCreatePlaylist()">+ New Playlist</button>
            </div>
        `;
        
        if (data.playlists.length === 0) {
            html += '<div class="empty-state"><div class="icon">📋</div><p>No playlists yet. Create one to get started.</p></div>';
        } else {
            html += '<div class="table-container"><table><thead><tr>';
            html += '<th>Name</th><th>Description</th><th>Tracks</th><th>Plays</th><th>Status</th><th>Actions</th>';
            html += '</tr></thead><tbody>';
            
            data.playlists.forEach(pl => {
                html += `<tr>
                    <td><strong>${this.esc(pl.name)}</strong></td>
                    <td>${this.esc(pl.description || '-')}</td>
                    <td>${pl.track_count || 0}</td>
                    <td>${pl.play_count || 0}</td>
                    <td><span class="badge ${pl.is_active ? 'badge-active' : 'badge-inactive'}">${pl.is_active ? 'Active' : 'Inactive'}</span></td>
                    <td>
                        <div class="actions-group">
                            <button class="btn btn-sm btn-secondary" onclick="App.viewPlaylist(${pl.id})">📝</button>
                            <button class="btn btn-sm btn-secondary" onclick="App.togglePlaylistActive(${pl.id})">${pl.is_active ? '⏸' : '▶'}</button>
                            <button class="btn btn-sm btn-danger" onclick="App.deletePlaylist(${pl.id})">🗑️</button>
                        </div>
                    </td>
                </tr>`;
            });
            html += '</tbody></table></div>';
        }
        
        document.getElementById('playlists-content').innerHTML = html;
    },
    
    async viewPlaylist(id) {
        const data = await API.get(`/playlists?action=get&id=${id}`);
        const playlist = data.playlist;
        const tracks = data.tracks;
        
        let tracksHtml = '';
        if (tracks.length === 0) {
            tracksHtml = '<p class="text-muted">No tracks in this playlist.</p>';
        } else {
            tracksHtml = `<table><thead><tr><th>#</th><th>Title</th><th>Artist</th><th>Duration</th><th>Actions</th></tr></thead><tbody>`;
            tracks.forEach((t, i) => {
                tracksHtml += `<tr>
                    <td>${i + 1}</td>
                    <td>${this.esc(t.title)}</td>
                    <td>${this.esc(t.artist)}</td>
                    <td>${t.duration ? this.formatDuration(t.duration) : '--:--'}</td>
                    <td><button class="btn btn-sm btn-danger" onclick="App.removeTrackFromPlaylist(${playlist.id},${t.id})">🗑️</button></td>
                </tr>`;
            });
            tracksHtml += '</tbody></table>';
        }
        
        document.getElementById('modal-content').innerHTML = `
            <div class="modal active" id="playlist-modal">
                <div class="modal">
                    <div class="flex-between">
                        <h3>${this.esc(playlist.name)}</h3>
                        <button class="btn btn-sm btn-secondary" onclick="App.closeModal('playlist-modal')">✕</button>
                    </div>
                    <p class="text-muted mb-20">${this.esc(playlist.description || 'No description')} • ${tracks.length} tracks</p>
                    <div class="form-group">
                        <label>Add Track by ID</label>
                        <div style="display:flex;gap:8px;">
                            <input type="number" class="form-control" id="add-track-id" placeholder="Track ID" style="flex:1;">
                            <button class="btn btn-primary btn-sm" onclick="App.addTrackToPlaylistById(${playlist.id})">Add</button>
                        </div>
                    </div>
                    <div id="playlist-tracks">${tracksHtml}</div>
                </div>
            </div>
        `;
    },
    
    async addTrackToPlaylistById(playlistId) {
        const trackId = parseInt(document.getElementById('add-track-id').value);
        if (!trackId) return;
        try {
            await API.post('/playlists?action=add_track', { playlist_id: playlistId, track_id: trackId });
            this.showAlert('success', 'Track added!');
            this.viewPlaylist(playlistId);
        } catch (err) {
            this.showAlert('error', err.message);
        }
    },
    
    async removeTrackFromPlaylist(playlistId, trackId) {
        try {
            await API.post('/playlists?action=remove_track', { playlist_id: playlistId, track_id: trackId });
            this.viewPlaylist(playlistId);
        } catch (err) {
            this.showAlert('error', err.message);
        }
    },
    
    showCreatePlaylist() {
        document.getElementById('modal-content').innerHTML = `
            <div class="modal active" id="create-playlist-modal">
                <div class="modal">
                    <div class="flex-between">
                        <h3>Create Playlist</h3>
                        <button class="btn btn-sm btn-secondary" onclick="App.closeModal('create-playlist-modal')">✕</button>
                    </div>
                    <div class="form-group mt-20">
                        <label>Playlist Name</label>
                        <input type="text" class="form-control" id="new-playlist-name" placeholder="Enter playlist name">
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <input type="text" class="form-control" id="new-playlist-desc" placeholder="Optional description">
                    </div>
                    <button class="btn btn-primary btn-block mt-10" onclick="App.createPlaylist()">Create</button>
                </div>
            </div>
        `;
    },
    
    async createPlaylist() {
        const name = document.getElementById('new-playlist-name').value.trim();
        const desc = document.getElementById('new-playlist-desc').value.trim();
        if (!name) { this.showAlert('error', 'Name is required'); return; }
        try {
            await API.post('/playlists?action=create', { name, description: desc });
            this.closeModal('create-playlist-modal');
            this.loadPlaylists();
            this.showAlert('success', 'Playlist created!');
        } catch (err) {
            this.showAlert('error', err.message);
        }
    },
    
    async togglePlaylistActive(id) {
        try {
            await API.post('/playlists?action=toggle_active', { id });
            this.loadPlaylists();
        } catch (err) {
            this.showAlert('error', err.message);
        }
    },
    
    async deletePlaylist(id) {
        if (!confirm('Delete this playlist and all its track associations?')) return;
        try {
            await API.post('/playlists?action=delete', { id });
            this.loadPlaylists();
            this.showAlert('success', 'Playlist deleted');
        } catch (err) {
            this.showAlert('error', err.message);
        }
    },
    
    async loadAutoDJ() {
        const data = await API.get('/autodj?action=status');
        const autodj = data.autodj;
        const settings = data.settings;
        
        document.getElementById('autodj-status').innerHTML = `
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon ${autodj.running ? 'green' : 'red'}">🔄</div>
                    <div class="stat-info">
                        <h4>AutoDJ</h4>
                        <div class="stat-value">${autodj.running ? '<span style="color:var(--accent-green)">● Running</span>' : '<span style="color:var(--accent-red)">● Stopped</span>'}</div>
                        <div class="stat-label">PID: ${autodj.pid || 'N/A'}</div>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon cyan">📡</div>
                    <div class="stat-info">
                        <h4>Icecast</h4>
                        <div class="stat-value">${autodj.icecast_online ? '<span style="color:var(--accent-green)">● Online</span>' : '<span style="color:var(--accent-red)">● Offline</span>'}</div>
                        <div class="stat-label">${autodj.listeners || 0} listeners</div>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon orange">🎙️</div>
                    <div class="stat-info">
                        <h4>Live Source</h4>
                        <div class="stat-value">${autodj.live_source?.active ? '<span style="color:var(--accent-red)">● Active</span>' : '<span style="color:var(--text-muted)">● Inactive</span>'}</div>
                        <div class="stat-label">${autodj.live_source?.active ? 'AutoDJ paused' : 'AutoDJ active'}</div>
                    </div>
                </div>
            </div>
        `;
        
        document.getElementById('autodj-controls').innerHTML = `
            <div style="display:flex;gap:8px;flex-wrap:wrap;">
                <button class="btn btn-success" onclick="App.startAutoDJ()" ${autodj.running ? 'disabled' : ''}>▶ Start</button>
                <button class="btn btn-warning" onclick="App.restartAutoDJ()" ${!autodj.running ? 'disabled' : ''}>↻ Restart</button>
                <button class="btn btn-danger" onclick="App.stopAutoDJ()" ${!autodj.running ? 'disabled' : ''}>■ Stop</button>
            </div>
        `;
        
        if (settings) {
            document.getElementById('stream-settings-form').innerHTML = `
                <div class="form-row">
                    <div class="form-group">
                        <label>Stream Name</label>
                        <input type="text" class="form-control" id="stream-name" value="${this.esc(settings.stream_name || '')}">
                    </div>
                    <div class="form-group">
                        <label>Genre</label>
                        <input type="text" class="form-control" id="stream-genre" value="${this.esc(settings.stream_genre || '')}">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Stream URL</label>
                        <input type="text" class="form-control" id="stream-url" value="${this.esc(settings.stream_url || '')}">
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <input type="text" class="form-control" id="stream-description" value="${this.esc(settings.stream_description || '')}">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Icecast Host</label>
                        <input type="text" class="form-control" id="icecast-host" value="${this.esc(settings.icecast_host || '')}">
                    </div>
                    <div class="form-group">
                        <label>Icecast Port</label>
                        <input type="number" class="form-control" id="icecast-port" value="${settings.icecast_port || 8000}">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Mount Point</label>
                        <input type="text" class="form-control" id="icecast-mount" value="${this.esc(settings.icecast_mount || '/stream')}">
                    </div>
                    <div class="form-group">
                        <label>Source Password</label>
                        <input type="password" class="form-control" id="icecast-password" value="${this.esc(settings.icecast_password || '')}">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Bitrate (kbps)</label>
                        <select class="form-control" id="stream-bitrate">
                            <option value="64" ${settings.bitrate == 64 ? 'selected' : ''}>64</option>
                            <option value="96" ${settings.bitrate == 96 ? 'selected' : ''}>96</option>
                            <option value="128" ${settings.bitrate == 128 ? 'selected' : ''}>128 (Recommended)</option>
                            <option value="192" ${settings.bitrate == 192 ? 'selected' : ''}>192</option>
                            <option value="256" ${settings.bitrate == 256 ? 'selected' : ''}>256</option>
                            <option value="320" ${settings.bitrate == 320 ? 'selected' : ''}>320</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Sample Rate</label>
                        <select class="form-control" id="stream-samplerate">
                            <option value="22050" ${settings.samplerate == 22050 ? 'selected' : ''}>22050 Hz</option>
                            <option value="44100" ${settings.samplerate == 44100 ? 'selected' : ''}>44100 Hz (CD)</option>
                            <option value="48000" ${settings.samplerate == 48000 ? 'selected' : ''}>48000 Hz</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Format</label>
                        <select class="form-control" id="stream-format">
                            <option value="mp3" ${settings.format == 'mp3' ? 'selected' : ''}>MP3</option>
                            <option value="ogg" ${settings.format == 'ogg' ? 'selected' : ''}>OGG Vorbis</option>
                        </select>
                    </div>
                </div>
                <button class="btn btn-primary" onclick="App.saveSettings()">💾 Save Settings</button>
            `;
        }
    },
    
    async startAutoDJ() {
        try {
            await API.post('/autodj?action=start');
            this.showAlert('success', 'AutoDJ started!');
            await this.loadAutoDJ();
            await this.loadDashboard();
        } catch (err) {
            this.showAlert('error', err.message);
        }
    },
    
    async stopAutoDJ() {
        try {
            await API.post('/autodj?action=stop');
            this.showAlert('success', 'AutoDJ stopped');
            await this.loadAutoDJ();
            await this.loadDashboard();
        } catch (err) {
            this.showAlert('error', err.message);
        }
    },
    
    async restartAutoDJ() {
        try {
            await API.post('/autodj?action=restart');
            this.showAlert('success', 'AutoDJ restarting...');
            setTimeout(() => { this.loadAutoDJ(); this.loadDashboard(); }, 2000);
        } catch (err) {
            this.showAlert('error', err.message);
        }
    },
    
    async saveSettings() {
        const settings = {
            action: 'save_settings',
            stream_name: document.getElementById('stream-name').value,
            stream_genre: document.getElementById('stream-genre').value,
            stream_url: document.getElementById('stream-url').value,
            stream_description: document.getElementById('stream-description').value,
            icecast_host: document.getElementById('icecast-host').value,
            icecast_port: document.getElementById('icecast-port').value,
            icecast_mount: document.getElementById('icecast-mount').value,
            icecast_password: document.getElementById('icecast-password').value,
            bitrate: document.getElementById('stream-bitrate').value,
            samplerate: document.getElementById('stream-samplerate').value,
            format: document.getElementById('stream-format').value
        };
        try {
            await API.post('/autodj?action=save_settings', settings);
            this.showAlert('success', 'Settings saved! Restart AutoDJ to apply.');
        } catch (err) {
            this.showAlert('error', err.message);
        }
    },
    
    async loadSchedule() {
        const data = await API.get('/schedule?action=list');
        let html = `
            <div class="flex-between mb-20">
                <h3>Schedule</h3>
                <button class="btn btn-primary" onclick="App.showCreateSchedule()">+ Add Schedule</button>
            </div>
        `;
        if (data.schedules.length === 0) {
            html += '<div class="empty-state"><div class="icon">📅</div><p>No schedules configured.</p></div>';
        } else {
            html += `<table><thead><tr><th>Playlist</th><th>Day</th><th>Start</th><th>End</th><th>Active</th><th>Actions</th></tr></thead><tbody>`;
            data.schedules.forEach(s => {
                html += `<tr>
                    <td><strong>${this.esc(s.playlist_name || 'Unknown')}</strong></td>
                    <td>${this.esc(s.day_of_week)}</td>
                    <td>${this.esc(s.start_time)}</td>
                    <td>${this.esc(s.end_time)}</td>
                    <td><span class="badge ${s.is_active ? 'badge-active' : 'badge-inactive'}">${s.is_active ? 'Active' : 'Inactive'}</span></td>
                    <td>
                        <div class="actions-group">
                            <button class="btn btn-sm btn-secondary" onclick="App.toggleSchedule(${s.id})">${s.is_active ? '⏸' : '▶'}</button>
                            <button class="btn btn-sm btn-danger" onclick="App.deleteSchedule(${s.id})">🗑️</button>
                        </div>
                    </td>
                </tr>`;
            });
            html += '</tbody></table>';
        }
        document.getElementById('schedule-content').innerHTML = html;
    },
    
    showCreateSchedule() {
        document.getElementById('modal-content').innerHTML = `
            <div class="modal active" id="schedule-modal">
                <div class="modal">
                    <div class="flex-between">
                        <h3>Create Schedule</h3>
                        <button class="btn btn-sm btn-secondary" onclick="App.closeModal('schedule-modal')">✕</button>
                    </div>
                    <div class="form-group mt-20">
                        <label>Playlist</label>
                        <select class="form-control" id="schedule-playlist"></select>
                    </div>
                    <div class="form-group">
                        <label>Day of Week</label>
                        <select class="form-control" id="schedule-day">
                            <option>Monday</option><option>Tuesday</option><option>Wednesday</option>
                            <option>Thursday</option><option>Friday</option><option>Saturday</option><option>Sunday</option>
                        </select>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Start Time</label>
                            <input type="time" class="form-control" id="schedule-start" value="08:00">
                        </div>
                        <div class="form-group">
                            <label>End Time</label>
                            <input type="time" class="form-control" id="schedule-end" value="18:00">
                        </div>
                    </div>
                    <button class="btn btn-primary btn-block mt-10" onclick="App.createSchedule()">Create Schedule</button>
                </div>
            </div>
        `;
        API.get('/playlists?action=list').then(data => {
            const sel = document.getElementById('schedule-playlist');
            sel.innerHTML = data.playlists.map(p => `<option value="${p.id}">${this.esc(p.name)}</option>`).join('');
        });
    },
    
    async createSchedule() {
        const data = {
            action: 'create',
            playlist_id: document.getElementById('schedule-playlist').value,
            day_of_week: document.getElementById('schedule-day').value,
            start_time: document.getElementById('schedule-start').value,
            end_time: document.getElementById('schedule-end').value
        };
        try {
            await API.post('/schedule?action=create', data);
            this.closeModal('schedule-modal');
            this.loadSchedule();
            this.showAlert('success', 'Schedule created!');
        } catch (err) {
            this.showAlert('error', err.message);
        }
    },
    
    async toggleSchedule(id) {
        try { await API.post('/schedule?action=toggle', { id }); this.loadSchedule(); } catch (err) { this.showAlert('error', err.message); }
    },
    
    async deleteSchedule(id) {
        if (!confirm('Delete this schedule?')) return;
        try { await API.post('/schedule?action=delete', { id }); this.loadSchedule(); } catch (err) { this.showAlert('error', err.message); }
    },
    
    async loadDJs() {
        const data = await API.get('/users?action=list');
        let html = `
            <div class="flex-between mb-20">
                <h3>DJ Management</h3>
                <button class="btn btn-primary" onclick="App.showCreateUser()">+ Add DJ</button>
            </div>
        `;
        html += `<div class="table-container"><table><thead><tr>
            <th>Username</th><th>Email</th><th>Role</th><th>Status</th><th>Last Login</th><th>Actions</th>
        </tr></thead><tbody>`;
        data.users.forEach(u => {
            html += `<tr>
                <td><strong>${this.esc(u.username)}</strong></td>
                <td>${this.esc(u.email || '-')}</td>
                <td><span class="badge ${u.role === 'admin' ? 'badge-admin' : 'badge-dj'}">${this.esc(u.role)}</span></td>
                <td><span class="badge ${u.is_active ? 'badge-active' : 'badge-inactive'}">${u.is_active ? 'Active' : 'Disabled'}</span></td>
                <td>${u.last_login ? this.esc(u.last_login) : 'Never'}</td>
                <td>
                    <div class="actions-group">
                        <button class="btn btn-sm btn-secondary" onclick="App.toggleUser(${u.id})">${u.is_active ? '⏸' : '▶'}</button>
                        ${u.role !== 'admin' ? `<button class="btn btn-sm btn-danger" onclick="App.deleteUser(${u.id})">🗑️</button>` : ''}
                    </div>
                </td>
            </tr>`;
        });
        html += '</tbody></table>';
        
        try {
            const sessions = await API.get('/users?action=active_djs');
            if (sessions.djs.length > 0) {
                html += `<h3 class="mt-20">Active Sessions</h3><table><thead><tr>
                    <th>DJ</th><th>Connected</th><th>IP Address</th>
                </tr></thead><tbody>`;
                sessions.djs.forEach(s => {
                    html += `<tr>
                        <td>${this.esc(s.username)}</td>
                        <td>${this.esc(s.connected_at)}</td>
                        <td>${this.esc(s.ip_address || '-')}</td>
                    </tr>`;
                });
                html += '</tbody></table>';
            }
        } catch(e) {}
        
        document.getElementById('djs-content').innerHTML = html;
    },
    
    showCreateUser() {
        document.getElementById('modal-content').innerHTML = `
            <div class="modal active" id="create-user-modal">
                <div class="modal">
                    <div class="flex-between">
                        <h3>Add DJ</h3>
                        <button class="btn btn-sm btn-secondary" onclick="App.closeModal('create-user-modal')">✕</button>
                    </div>
                    <div class="form-group mt-20">
                        <label>Username</label>
                        <input type="text" class="form-control" id="new-username" placeholder="Choose a username">
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" class="form-control" id="new-password" placeholder="Min 8 characters">
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" class="form-control" id="new-email" placeholder="DJ email">
                    </div>
                    <div class="form-group">
                        <label>Role</label>
                        <select class="form-control" id="new-role">
                            <option value="dj">DJ</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                    <button class="btn btn-primary btn-block mt-10" onclick="App.createUser()">Create DJ Account</button>
                </div>
            </div>
        `;
    },
    
    async createUser() {
        const data = {
            action: 'create',
            username: document.getElementById('new-username').value.trim(),
            password: document.getElementById('new-password').value,
            email: document.getElementById('new-email').value.trim(),
            role: document.getElementById('new-role').value
        };
        if (!data.username || !data.password) { this.showAlert('error', 'Username and password required'); return; }
        try {
            await API.post('/users?action=create', data);
            this.closeModal('create-user-modal');
            this.loadDJs();
            this.showAlert('success', 'DJ account created!');
        } catch (err) { this.showAlert('error', err.message); }
    },
    
    async toggleUser(id) {
        try { await API.post('/users?action=toggle_active', { id }); this.loadDJs(); } catch (err) { this.showAlert('error', err.message); }
    },
    
    async deleteUser(id) {
        if (!confirm('Delete this DJ account?')) return;
        try { await API.post('/users?action=delete', { id }); this.loadDJs(); } catch (err) { this.showAlert('error', err.message); }
    },
    
    async loadLive() {
        try {
            const [liveStatus, settings] = await Promise.all([
                API.get('/live?action=status'),
                API.get('/autodj?action=config')
            ]);
            
            document.getElementById('live-content').innerHTML = `
                <div class="card">
                    <h3 class="mb-20">🎙️ Live DJ Takeover</h3>
                    <div class="stats-grid">
                        <div class="stat-card">
                            <div class="stat-icon ${liveStatus.active ? 'red' : 'green'}">
                                ${liveStatus.active ? '🔴' : '🟢'}
                            </div>
                            <div class="stat-info">
                                <h4>Status</h4>
                                <div class="stat-value">${liveStatus.active ? 'LIVE ACTIVE' : 'AutoDJ Mode'}</div>
                                ${liveStatus.active ? `<div class="stat-label">DJ: ${this.esc(liveStatus.dj || 'Unknown')}</div>` : ''}
                            </div>
                        </div>
                    </div>
                    
                    ${liveStatus.active ? `
                        <div style="margin-top:20px;">
                            <p class="mb-10"><strong>Current DJ:</strong> ${this.esc(liveStatus.dj)}</p>
                            <p class="mb-20"><strong>Started:</strong> ${new Date(liveStatus.started * 1000).toLocaleString()}</p>
                            <button class="btn btn-danger" onclick="App.endTakeover()">⏹ End Takeover</button>
                        </div>
                    ` : `
                        <div class="mt-20">
                            <h4>Connect with your source client:</h4>
                            <div class="code-block">
Server: ${this.esc(settings.settings?.icecast_host || 'localhost')}
Port: ${settings.settings?.icecast_port || 8000}
Mount: ${this.esc(settings.settings?.icecast_mount || '/stream')}
Password: ${this.esc(settings.settings?.icecast_password || 'hackme')}
                            </div>
                            <p class="text-muted mt-10">Use these credentials in <strong>BUTT</strong>, <strong>Mixxx</strong>, or <strong>SAM Broadcaster</strong></p>
                            <button class="btn btn-success mt-10" onclick="App.requestTakeover()">🎙️ Request Live Takeover</button>
                        </div>
                    `}
                </div>
            `;
        } catch(err) {
            this.showAlert('error', err.message);
        }
    },
    
    async requestTakeover() {
        try {
            const data = await API.post('/live?action=request');
            this.showAlert('success', `Takeover granted! Token: ${data.token}`);
            this.loadLive();
        } catch (err) { this.showAlert('error', err.message); }
    },
    
    async endTakeover() {
        try {
            await API.post('/live?action=end');
            this.showAlert('success', 'Takeover ended. AutoDJ resumed.');
            this.loadLive();
            this.loadDashboard();
        } catch (err) { this.showAlert('error', err.message); }
    },
    
    async loadSettings() {
        await this.loadAutoDJ();
    },
    
    setupLogin() {
        const loginForm = document.getElementById('login-form');
        if (!loginForm) return;
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const btn = loginForm.querySelector('button[type="submit"]');
            btn.disabled = true;
            btn.textContent = 'Logging in...';
            try {
                const data = await API.post('/login?action=login', {
                    username: document.getElementById('username').value,
                    password: document.getElementById('password').value
                });
                localStorage.setItem('radiolite_token', 'authenticated');
                if (data.force_password_change) {
                    window.location.href = '/change-password';
                } else {
                    window.location.href = '/?page=dashboard';
                }
            } catch (err) {
                this.showAlert('error', err.message || 'Login failed');
                btn.disabled = false;
                btn.textContent = 'Sign In';
            }
        });
    },
    
    showAlert(type, message) {
        const alert = document.createElement('div');
        alert.className = `alert alert-${type}`;
        alert.textContent = message;
        alert.style.display = 'block';
        const container = document.querySelector('.page-content') || document.body;
        container.insertBefore(alert, container.firstChild);
        setTimeout(() => alert.remove(), 5000);
    },
    
    esc(str) {
        if (!str) return '';
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    },
    
    formatDuration(seconds) {
        if (!seconds || seconds <= 0) return '--:--';
        const m = Math.floor(seconds / 60);
        const s = Math.floor(seconds % 60);
        return `${m}:${s.toString().padStart(2, '0')}`;
    },
    
    formatBytes(bytes) {
        if (!bytes) return '-';
        if (bytes >= 1073741824) return (bytes / 1073741824).toFixed(2) + ' GB';
        if (bytes >= 1048576) return (bytes / 1048576).toFixed(2) + ' MB';
        if (bytes >= 1024) return (bytes / 1024).toFixed(2) + ' KB';
        return bytes + ' B';
    },
    
    startAutoRefresh() {
        if (this.autoRefresh) clearInterval(this.autoRefresh);
        this.autoRefresh = setInterval(() => {
            if (['dashboard', 'autodj', 'live'].includes(this.currentPage)) {
                this.loadPageData(this.currentPage);
            }
        }, this.refreshInterval);
    }
};

document.addEventListener('DOMContentLoaded', () => {
    App.init();
    App.startAutoRefresh();
    window.addEventListener('popstate', (e) => {
        if (e.state && e.state.page) App.navigate(e.state.page);
    });
    const params = new URLSearchParams(window.location.search);
    const page = params.get('page') || 'dashboard';
    App.navigate(page);
});