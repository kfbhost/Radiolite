<?php
/**
 * RadioLite - API Router
 * Routes all API requests to appropriate handlers
 */

// Allow from any origin (restrict in production)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Define base paths
define('APP_DIR', '/opt/radiolite/app');
define('PUBLIC_DIR', '/opt/radiolite/public');

// Autoloader
spl_autoload_register(function ($class) {
    $file = APP_DIR . '/includes/' . strtolower($class) . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});

// Require dependencies
require_once APP_DIR . '/config/db.php';
require_once APP_DIR . '/config/config.php';
require_once APP_DIR . '/includes/auth.php';
require_once APP_DIR . '/includes/helpers.php';
require_once APP_DIR . '/includes/tracks.php';
require_once APP_DIR . '/includes/playlists.php';
require_once APP_DIR . '/includes/users.php';
require_once APP_DIR . '/includes/autodj.php';
require_once APP_DIR . '/includes/schedule.php';
require_once APP_DIR . '/includes/live.php';

// Initialize database on first run
$dbPath = Config::DB_PATH;
if (!file_exists($dbPath)) {
    Database::init();
    
    // Create default admin with hashed password
    $db = new PDO("sqlite:" . $dbPath);
    $hash = password_hash('admin123', PASSWORD_BCRYPT);
    $db->prepare("INSERT OR IGNORE INTO users (username, password, email, role, force_password_change, is_active) 
                  VALUES ('admin', ?, 'admin@radiolite.local', 'admin', 1, 1)")
       ->execute([$hash]);
}

// Parse endpoint from URL
$endpoint = $_GET['endpoint'] ?? '';
$endpoint = trim($endpoint, '/');

// Handle file uploads separately (multipart/form-data)
if ($endpoint === 'upload' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once APP_DIR . '/api/upload.php';
    exit;
}

// JSON API endpoints
header('Content-Type: application/json');

// Read JSON input
$input = json_decode(file_get_contents('php://input'), true);
if ($input && is_array($input)) {
    $_POST = array_merge($_POST, $input);
}

// Also support action parameter
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($endpoint) {
    case 'login':
        require_once APP_DIR . '/api/login.php';
        break;
        
    case 'tracks':
        require_once APP_DIR . '/api/tracks.php';
        break;
        
    case 'playlists':
        require_once APP_DIR . '/api/playlists.php';
        break;
        
    case 'autodj':
        require_once APP_DIR . '/api/autodj.php';
        break;
        
    case 'schedule':
        require_once APP_DIR . '/api/schedule.php';
        break;
        
    case 'users':
        require_once APP_DIR . '/api/users.php';
        break;
        
    case 'live':
        require_once APP_DIR . '/api/live.php';
        break;
        
    case 'status':
        // Public status endpoint
        $autodjStatus = AutoDJ::getStatus();
        $nowPlaying = getNowPlaying();
        $icecastStatus = getIcecastStatus();
        
        jsonResponse([
            'station' => Config::APP_NAME,
            'version' => Config::APP_VERSION,
            'now_playing' => $nowPlaying,
            'autodj' => $autodjStatus,
            'icecast' => $icecastStatus
        ]);
        break;
        
    default:
        http_response_code(404);
        jsonResponse(['error' => 'Endpoint not found']);
}