<?php
require_once __DIR__ . '/../app/config/db.php';
require_once __DIR__ . '/../app/config/config.php';
require_once __DIR__ . '/../app/includes/auth.php';

Auth::requireLogin();

$user = Auth::getUser();
if (!$user['force_password_change']) {
    header('Location: /?page=dashboard');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current = $_POST['current_password'] ?? '';
    $new = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    
    if ($new !== $confirm) {
        $error = 'New passwords do not match';
    } elseif (strlen($new) < 8) {
        $error = 'Password must be at least 8 characters';
    } else {
        $result = Auth::changePassword($user['id'], $current, $new);
        if ($result['success']) {
            $success = 'Password changed successfully! Redirecting...';
            header('Refresh: 2; URL=/?page=dashboard');
        } else {
            $error = $result['error'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RadioLite - Change Password</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
<div class="login-container">
    <div class="login-card" style="max-width:420px;">
        <div class="login-logo">🔒</div>
        <h2>Change Password</h2>
        <p class="login-subtitle">Required for first login</p>
        
        <?php if ($error): ?>
            <div class="alert alert-danger" style="display:block;"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success" style="display:block;"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label>Current Password</label>
                <input type="password" class="form-control" name="current_password" required>
            </div>
            <div class="form-group">
                <label>New Password</label>
                <input type="password" class="form-control" name="new_password" required minlength="8">
            </div>
            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" class="form-control" name="confirm_password" required minlength="8">
            </div>
            <button type="submit" class="btn btn-primary btn-block">Change Password</button>
        </form>
    </div>
</div>
</body>
</html>