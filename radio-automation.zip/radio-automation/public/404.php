<?php
http_response_code(404);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Page Not Found | RadioLite</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
<div class="login-container">
    <div class="login-card" style="max-width:500px;text-align:center;">
        <div style="font-size:4rem;margin-bottom:20px;">📻</div>
        <h2 style="margin-bottom:10px;">404 — Page Not Found</h2>
        <p class="text-muted">The page you're looking for doesn't exist.</p>
        <a href="/" class="btn btn-primary mt-20">← Back to Dashboard</a>
    </div>
</div>
</body>
</html>