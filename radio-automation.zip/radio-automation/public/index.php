<?php
require_once __DIR__ . '/../app/config/db.php';
require_once __DIR__ . '/../app/config/config.php';
require_once __DIR__ . '/../app/includes/auth.php';
require_once __DIR__ . '/../app/includes/helpers.php';

Auth::requireLogin();

$user = Auth::getUser();
$nowPlaying = getNowPlaying();
$autodjStatus = AutoDJ::getStatus();
$liveStatus = LiveTakeover::isLiveActive();

// Force password change
if ($user['force_password_change']) {
    header('Location: /change-password.php');
    exit;
}

$currentPage = isset($_GET['page']) ? $_GET['page'] : 'dashboard';
$allowedPages = ['dashboard', 'library', 'playlists', 'upload', 'autodj', 'schedule', 'djs', 'live', 'settings'];
if (!in_array($currentPage, $allowedPages)) $currentPage = 'dashboard';

function e($str) { return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RadioLite - Dashboard</title>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>📻</text></svg>">
</head>
<body>
<div class="app-container">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <h1>📻 RadioLite</h1>
            <small>v1.0.0 — Internet Radio</small>
        </div>
        <nav class="sidebar-nav">
            <div class="nav-item <?php echo $currentPage === 'dashboard' ? 'active' : '' ?>" data-page="dashboard">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/></svg>
                Dashboard
            </div>
            <div class="nav-item <?php echo $currentPage === 'library' ? 'active' : '' ?>" data-page="library">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg>
                Music Library
            </div>
            <div class="nav-item <?php echo $currentPage === 'playlists' ? 'active' : '' ?>" data-page="playlists">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
                Playlists
            </div>
            <div class="nav-item <?php echo $currentPage === 'upload' ? 'active' : '' ?>" data-page="upload">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                Upload Music
            </div>
            <div class="nav-item <?php echo $currentPage === 'autodj' ? 'active' : '' ?>" data-page="autodj">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M8 12h8M12 8v8"/></svg>
                AutoDJ
            </div>
            <div class="nav-item <?php echo $currentPage === 'live' ? 'active' : '' ?>" data-page="live">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 006 0V4a3 3 0 00-3-3z"/><path d="M19 10v2a7 7 0 01-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>
                Live DJ
            </div>
            <div class="nav-item <?php echo $currentPage === 'schedule' ? 'active' : '' ?>" data-page="schedule">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                Schedule
            </div>
            <?php if ($user['role'] === 'admin'): ?>
            <div class="nav-item <?php echo $currentPage === 'djs' ? 'active' : '' ?>" data-page="djs">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>
                DJ Management
            </div>
            <div class="nav-item <?php echo $currentPage === 'settings' ? 'active' : '' ?>" data-page="settings">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 01-2.83 2.83l-.06-.06A1.65 1.65 0 0015 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>
                Settings
            </div>
            <?php endif; ?>
        </nav>
        <div style="padding:15px 20px;border-top:1px solid var(--border-color);position:absolute;bottom:0;width:260px;background:var(--bg-secondary);">
            <div class="user-badge" style="width:100%;justify-content:space-between;">
                <span>👤 <?php echo e($user['username']); ?></span>
                <a href="/logout.php" style="color:var(--text-muted);font-size:0.8rem;">Logout</a>
            </div>
            <?php if ($user['force_password_change']): ?>
                <a href="/change-password.php" style="color:var(--accent-orange);font-size:0.8rem;">⚠️ Change password required</a>
            <?php endif; ?>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <div class="topbar">
            <h2><?php echo ucfirst(e($currentPage)); ?></h2>
            <div class="topbar-right">
                <div class="user-badge">
                    <span>👤 <?php echo e($user['username']); ?></span>
                    <span class="badge <?php echo $user['role'] === 'admin' ? 'badge-admin' : 'badge-dj' ?>"><?php echo e($user['role']); ?></span>
                </div>
                <a href="/logout.php" class="btn btn-sm btn-secondary">Logout</a>
            </div>
        </div>

        <div class="page-content">
            <!-- Dashboard Page -->
            <div class="page-section" id="page-dashboard" style="display:<?php echo $currentPage === 'dashboard' ? 'block' : 'none' ?>">
                <div id="np-widget"></div>
                <div id="stats-container"></div>
                <div class="card">
                    <div class="card-header">
                        <h3>🎛️ AutoDJ Controls</h3>
                    </div>
                    <div id="autodj-controls"></div>
                </div>
                <div class="card">
                    <div class="card-header"><h3>📊 Quick Info</h3></div>
                    <p class="text-muted">Tracks in library: <strong id="track-count">-</strong> | Playlists: <strong id="playlist-count">-</strong></p>
                </div>
            </div>

            <!-- Library Page -->
            <div class="page-section" id="page-library" style="display:<?php echo $currentPage === 'library' ? 'block' : 'none' ?>">
                <div class="card">
                    <div class="card-header">
                        <h3>🎵 Music Library</h3>
                    </div>
                    <div id="library-content"></div>
                </div>
            </div>

            <!-- Upload Page -->
            <div class="page-section" id="page-upload" style="display:<?php echo $currentPage === 'upload' ? 'block' : 'none' ?>">
                <div class="card">
                    <div class="card-header"><h3>📤 Upload Music</h3></div>
                    <div class="upload-area" id="upload-area" onclick="document.getElementById('file-input').click()" ondrop="handleDrop(event)" ondragover="handleDragOver(event)" ondragleave="handleDragLeave(event)">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="var(--accent-blue)" stroke-width="1.5"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                        <h3>Drop files here or click to browse</h3>
                        <p>Supports MP3, OGG, FLAC, WAV, M4A, AAC (Max 50MB per file)</p>
                        <input type="file" id="file-input" multiple accept=".mp3,.ogg,.flac,.wav,.m4a,.aac" style="display:none" onchange="App.handleFileUpload(this)">
                    </div>
                    <div id="upload-progress" style="display:none;">
                        <div class="progress-bar"><div class="progress-fill" id="upload-progress-bar"></div></div>
                        <p id="upload-status" class="mt-10"></p>
                    </div>
                    <div id="upload-results"></div>
                </div>
            </div>

            <!-- Playlists Page -->
            <div class="page-section" id="page-playlists" style="display:<?php echo $currentPage === 'playlists' ? 'block' : 'none' ?>">
                <div class="card">
                    <div class="card-header"><h3>📋 Playlists</h3></div>
                    <div id="playlists-content"></div>
                </div>
            </div>

            <!-- AutoDJ Page -->
            <div class="page-section" id="page-autodj" style="display:<?php echo $currentPage === 'autodj' ? 'block' : 'none' ?>">
                <div class="card">
                    <div class="card-header"><h3>🔄 AutoDJ Engine</h3></div>
                    <div id="autodj-status"></div>
                    <div class="mt-20" id="autodj-controls"></div>
                </div>
                <div class="card mt-20">
                    <div class="card-header"><h3>⚙️ Stream Settings</h3></div>
                    <div id="stream-settings-form"></div>
                </div>
            </div>

            <!-- Schedule Page -->
            <div class="page-section" id="page-schedule" style="display:<?php echo $currentPage === 'schedule' ? 'block' : 'none' ?>">
                <div class="card">
                    <div class="card-header"><h3>📅 Playlist Schedule</h3></div>
                    <div id="schedule-content"></div>
                </div>
            </div>

            <!-- Live DJ Page -->
            <div class="page-section" id="page-live" style="display:<?php echo $currentPage === 'live' ? 'block' : 'none' ?>">
                <div class="card">
                    <div class="card-header"><h3>🎙️ Live DJ Takeover</h3></div>
                    <div id="live-content"></div>
                </div>
            </div>

            <!-- DJs Page -->
            <div class="page-section" id="page-djs" style="display:<?php echo $currentPage === 'djs' ? 'block' : 'none' ?>">
                <div class="card">
                    <div class="card-header"><h3>👥 DJ Management</h3></div>
                    <div id="djs-content"></div>
                </div>
            </div>

            <!-- Settings Page -->
            <div class="page-section" id="page-settings" style="display:<?php echo $currentPage === 'settings' ? 'block' : 'none' ?>">
                <div class="card">
                    <div class="card-header"><h3>⚙️ Stream Settings</h3></div>
                    <div id="settings-content"></div>
                </div>
            </div>
        </div>
    </main>
</div>

<!-- Modal Container -->
<div id="modal-content"></div>

<script src="/js/app.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const settingsContent = document.getElementById('settings-content');
        if (settingsContent) {
            settingsContent.innerHTML = document.getElementById('stream-settings-form')?.innerHTML || '<p>Loading...</p>';
        }
    });
</script>
</body>
</html>