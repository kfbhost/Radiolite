<?php
require_once __DIR__ . '/../app/config/db.php';
require_once __DIR__ . '/../app/config/config.php';
require_once __DIR__ . '/../app/includes/auth.php';

// If already logged in, redirect
if (Auth::isLoggedIn()) {
    $user = Auth::getUser();
    if ($user['force_password_change']) {
        header('Location: /change-password.php');
    } else {
        header('Location: /?page=dashboard');
    }
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (Auth::login($username, $password)) {
        $user = Auth::getUser();
        if ($user['force_password_change']) {
            header('Location: /change-password.php');
        } else {
            header('Location: /?page=dashboard');
        }
        exit;
    } else {
        $error = 'Invalid username or password';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RadioLite - Login</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
<div class="login-container">
    <div class="login-card">
        <div class="login-logo">📻</div>
        <h2>RadioLite</h2>
        <p class="login-subtitle">Internet Radio Automation System</p>
        
        <?php if ($error): ?>
            <div class="alert alert-danger" style="display:block;"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <form id="login-form" method="POST">
            <div class="form-group">
                <label>Username</label>
                <input type="text" class="form-control" id="username" name="username" 
                       placeholder="Enter your username" required autofocus>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" class="form-control" id="password" name="password" 
                       placeholder="Enter your password" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Sign In</button>
        </form>
        
        <p class="text-muted mt-20" style="text-align:center;font-size:0.8rem;">
            Default: admin / admin123
        </p>
    </div>
</div>
<script src="/js/app.js"></script>
</body>
</html>